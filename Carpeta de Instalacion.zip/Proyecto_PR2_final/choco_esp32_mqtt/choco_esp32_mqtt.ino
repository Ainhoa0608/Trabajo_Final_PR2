
  
 

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>

const char* WIFI_SSID = "WIFI_USURARIO";
const char* WIFI_PASSWORD = "TU_CONTRASEÑA";


const char* MQTT_HOST = "kf12786f.ala.us-east-1.emqxsl.com";
const uint16_t MQTT_PORT = 8883;
const char* MQTT_USER = "web_choco";
const char* MQTT_PASS = "asdfghjPOIU2345678";


const char* MQTT_SUBSCRIBE_FABRICA = "fabrica/#";
const char* MQTT_SUBSCRIBE_COMBI = "numero_combi/#";
const char* TOPIC_NUMERO_COMBI = "numero_combi/asignado";
const char* TOPIC_PEDIDO_GUARDADO = "fabrica/esp32/pedido_guardado";

WiFiClientSecure wifiTls;
PubSubClient mqtt(wifiTls);

int extraerEnteroJson(const String& json, const char* clave, int porDefecto = -1) {
  String patron = String("\"") + clave + "\"";
  int i = json.indexOf(patron);
  if (i < 0) return porDefecto;
  int dosPuntos = json.indexOf(':', i + patron.length());
  if (dosPuntos < 0) return porDefecto;
  int j = dosPuntos + 1;
  while (j < (int)json.length() && (json[j] == ' ' || json[j] == '\t' || json[j] == '\"')) j++;
  int k = j;
  if (k < (int)json.length() && json[k] == '-') k++;
  while (k < (int)json.length() && isDigit(json[k])) k++;
  if (k == j || (k == j + 1 && json[j] == '-')) return porDefecto;
  return json.substring(j, k).toInt();
}

void callbackMqtt(char* topic, byte* payload, unsigned int len) {
  String msg;
  msg.reserve(len + 1);
  for (unsigned int i = 0; i < len; i++) msg += (char)payload[i];

  Serial.print("[");
  Serial.print(topic);
  Serial.print("] ");
  Serial.print(msg);
  Serial.println();

  String topicStr = String(topic);
  if (topicStr == TOPIC_NUMERO_COMBI || topicStr == TOPIC_PEDIDO_GUARDADO) {
    int idPedido = extraerEnteroJson(msg, "idPedido", -1);
    int numeroCombi = extraerEnteroJson(msg, "numeroCombi", -1);
    if (numeroCombi >= 1) {
      Serial.print(">>> idPedido=");
      Serial.print(idPedido);
      Serial.print(" | numeroCombi=");
      Serial.println(numeroCombi);
      
    }
  }
}

void conectarWifi() {
  Serial.print("WiFi: ");
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  int t = 0;
  while (WiFi.status() != WL_CONNECTED && t < 40) {
    delay(500);
    Serial.print(".");
    t++;
  }
  Serial.println();
  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("WiFi OK, IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("WiFi ERROR");
  }
}

bool conectarMqtt() {
  String clientId = "esp32_choco_" + String((uint32_t)ESP.getEfuseMac(), HEX);
  if (mqtt.connect(clientId.c_str(), MQTT_USER, MQTT_PASS)) {
    Serial.println("MQTT conectado");
    if (mqtt.subscribe(MQTT_SUBSCRIBE_FABRICA)) {
      Serial.print("Suscrito: ");
      Serial.println(MQTT_SUBSCRIBE_FABRICA);
    }
    if (mqtt.subscribe(MQTT_SUBSCRIBE_COMBI)) {
      Serial.print("Suscrito: ");
      Serial.println(MQTT_SUBSCRIBE_COMBI);
    }
    return true;
  }
  Serial.print("MQTT fallo, estado=");
  Serial.println(mqtt.state());
  return false;
}

void setup() {
  Serial.begin(115200);
  delay(800);
  Serial.println();
  Serial.println(F("=== Choco ESP32 MQTT (arranque) ==="));
  Serial.flush();

  wifiTls.setInsecure();
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setCallback(callbackMqtt);
  mqtt.setBufferSize(8192);

  conectarWifi();
}

unsigned long ultimoIntento = 0;

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    conectarWifi();
    delay(2000);
    return;
  }

  if (!mqtt.connected()) {
    if (millis() - ultimoIntento > 3000) {
      ultimoIntento = millis();
      conectarMqtt();
    }
    return;
  }

  mqtt.loop();
}
