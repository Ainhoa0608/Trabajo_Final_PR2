<div align="center">

# 🍫 Fábrica de Bombones — PR2

<img src="https://img.shields.io/badge/Proyecto-Trabajo_Final_PR2-ff69b4?style=for-the-badge" alt="Proyecto PR2" />
<img src="https://img.shields.io/badge/Tienda_online-HTML·CSS·JS-f8b4d9?style=for-the-badge&logo=html5&logoColor=white" alt="Web" />
<img src="https://img.shields.io/badge/MQTT-EMQX-e91e8c?style=for-the-badge&logo=mqtt&logoColor=white" alt="MQTT" />

<br/><br/>

*Tienda web de bombones con pedidos, stock y conexión a la fábrica (MQTT / PostgreSQL).*

</div>

---

## 🌐 Página web

La web va dentro del archivo **`Pag.zip`**.

| Paso | Qué hacer |
|------|-----------|
| 1 | Descarga **`Pag.zip`** (botón verde *Code* → *Download ZIP*, o el enlace del archivo en este repo). |
| 2 | Descomprime la carpeta en tu PC. |
| 3 | Abre **`FABRICA DE BOMBONES.html`** con el navegador (Chrome, Edge, Firefox…). |

**Contenido del zip**

- `FABRICA DE BOMBONES.html` — página principal  
- `css/estilos.css` — diseño (incluye tonos rosa de la tienda)  
- `js/app.js` — lógica, carrito, MQTT  
- Imágenes de cajas y fondo  

> Para que funcione el carrito y los pedidos en tiempo real, el broker MQTT y el script `mqtt_bridge.py` deben estar activos en tu entorno (no van en este zip).

---

## 📦 Descarga rápida

⬇️ [**Pag.zip**](Pag.zip) — paquete completo de la página web

---

## 🛠️ Resto del proyecto (fuera de GitHub)

En local también tienes:

- `mqtt_bridge.py` — puente MQTT ↔ PostgreSQL  
- `mqtt_station_relay.py` — estación RoboDK  
- `diagnostico.py` — comprobar `.env`, BD y MQTT  
- Carpeta `sql/` — esquema de base de datos  

---

## 👤 Autora

**Ainhoa0608** — PR2 · UPV

<div align="center">

<img src="https://img.shields.io/badge/Hecho_con-💗-ff69b4?style=flat-square" alt="rosa" />

</div>
