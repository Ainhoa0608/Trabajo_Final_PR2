# COPIA TODO EN ROBODK -> Prog1 o Prog2 (Ctrl+A, Ctrl+V, Guardar, F5)
# Enseña place y preplace en la 1ª caja del PALET CENTRAL (Y ~ -300).
# No toca los targets en el arbol: mueve con poses calculadas.

from robodk import robolink
from robodk import robomath
import time

RDK = robolink.Robolink()

INCH = 25.4
CAJA_X = 16 * INCH
CAJA_Y = 24 * INCH
CAJA_Z = 16 * INCH

PALLET_L = 1200.0
PALLET_W = 800.0
PASO_X = CAJA_X / 2.0
PASO_Y = CAJA_Y / 2.0
PASO_Z = CAJA_Z

robot = RDK.Item('Robot_Cajas', robolink.ITEM_TYPE_ROBOT)
if not robot.Valid():
    raise Exception('No encuentro Robot_Cajas')

frame = RDK.Item('caja_grande', robolink.ITEM_TYPE_FRAME)
if frame.Valid():
    robot.setPoseFrame(frame)

def target(parcial):
    for item in RDK.ItemList(robolink.ITEM_TYPE_TARGET):
        if parcial.lower() in item.Name().lower():
            return item
    raise Exception('No encuentro target: %s' % parcial)

def target_paso_simple():
    for item in RDK.ItemList(robolink.ITEM_TYPE_TARGET):
        n = item.Name().lower()
        if n == 'paso' or (n.startswith('paso') and 'paso_2' not in n and 'paso2' not in n):
            return item
    raise Exception('No encuentro Paso')

prepick = target('prepick')
pick = target('pick_caja')
paso = target_paso_simple()
paso2 = target('paso_2')
aprox = target('aprox')

pose_place_0 = target('place_caja').Pose()
pose_preplace_0 = target('preplace').Pose()
# preplace siempre con el mismo offset respecto a place (como lo enseñaste)
T_pp_desde_place = pose_preplace_0 * pose_place_0.inv()

PALETS_Y = [-1200.0, -300.0, 600.0]

candidatos = []
for item in RDK.ItemList(robolink.ITEM_TYPE_OBJECT):
    if 'pallet' in item.Name().lower() or 'palet' in item.Name().lower():
        p = item.Pose().Pos()
        candidatos.append((item, p[0], p[1], item.Pose()))

palets = []
for y_ref in PALETS_Y:
    mejor = None
    mejor_dy = 1e9
    for item, x, y, pose in candidatos:
        dy = abs(y - y_ref)
        if dy < mejor_dy:
            mejor_dy = dy
            mejor = (item, x, y, pose)
    if mejor is None:
        raise Exception('No encuentro palet Y=%.0f' % y_ref)
    item, x, y, pose = mejor
    palets.append({'nombre': item.Name(), 'x': x, 'y': y, 'pose': pose})

palet_centro = min(palets, key=lambda p: abs(p['y'] + 300.0))
pos_centro = palet_centro['pose'].Pos()

COLS = 1 + int((PALLET_L - CAJA_X) // (2 * PASO_X))
ROWS = 1 + int((PALLET_W - CAJA_Y) // (2 * PASO_Y))
CAPAS = 4
TOTAL = COLS * ROWS * CAPAS * 3

print('=== PALETIZADO ===')
print('Base %dx%d | %d pisos | %d/palet | %d total' % (COLS, ROWS, CAPAS, COLS * ROWS * CAPAS, TOTAL))
print('Referencia place en: %s (Y=%.0f)' % (palet_centro['nombre'], palet_centro['y']))
for p in palets:
    print(' - %s  X=%.0f Y=%.0f' % (p['nombre'], p['x'], p['y']))
print('')

RDK.setSimulationSpeed(3)
robot.setSpeedJoints(50)
robot.setSpeed(150)

otros = [p for p in palets if p['nombre'] != palet_centro['nombre']]
palets_orden = [palet_centro] + otros

n = 0
for palet in palets_orden:
    pos_p = palet['pose'].Pos()
    T_delta_palet = robomath.transl(
        pos_p[0] - pos_centro[0],
        pos_p[1] - pos_centro[1],
        pos_p[2] - pos_centro[2],
    )

    for k in range(CAPAS):
        for j in range(ROWS):
            for i in range(COLS):
                n += 1

                ox = -i * (2 * PASO_X)
                oy = -j * (2 * PASO_Y)
                oz = k * PASO_Z
                if k % 2 == 1:
                    ox -= PASO_X
                    oy -= PASO_Y

                T_hueco = robomath.transl(ox, oy, oz)
                P_place = T_delta_palet * pose_place_0 * T_hueco
                P_preplace = P_place * T_pp_desde_place

                print('Caja %d/%d | %s | i=%d j=%d k=%d' % (n, TOTAL, palet['nombre'], i, j, k))

                robot.MoveJ(prepick)
                robot.MoveL(pick)
                robot.MoveL(prepick)
                robot.MoveJ(paso)
                robot.MoveJ(paso2)
                robot.MoveJ(aprox)

                # Mover a la pose calculada (NO setPose: no rompe preplace_caja_grande del arbol)
                robot.MoveJ(P_preplace)
                robot.MoveL(P_place)
                robot.MoveL(P_preplace)

                robot.MoveJ(aprox)
                robot.MoveJ(paso2)
                robot.MoveJ(paso)

                time.sleep(0.05)

print('Terminado: %d cajas' % n)
