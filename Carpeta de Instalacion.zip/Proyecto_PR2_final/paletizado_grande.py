# Solo movimientos RoboDK (sin caja ni ventosa).

from robodk import robolink
from robodk import robomath
import time

RDK = robolink.Robolink()
robot = RDK.Item('ABB IRB 4400/L30 M2000', robolink.ITEM_TYPE_ROBOT)

reposoG = RDK.Item('REPOSO_GRANDE', robolink.ITEM_TYPE_TARGET)
prepickG = RDK.Item('PREPRICK_GRANDE', robolink.ITEM_TYPE_TARGET)
pickG = RDK.Item('pick_grande', robolink.ITEM_TYPE_TARGET)
aprox_pickG = RDK.Item('APROX_GRANDE_PICK', robolink.ITEM_TYPE_TARGET)
placeG = RDK.Item('PLACEG', robolink.ITEM_TYPE_TARGET)
preplaceG = RDK.Item('PREPLACEG', robolink.ITEM_TYPE_TARGET)
aprox_placeG = RDK.Item('APROX_GRANDE_PLACE', robolink.ITEM_TYPE_TARGET)

filas, columnas, altura = 2, 2, 2
paso_x, paso_y, paso_z = 610, 410, 250

pose_PrePlace_0 = preplaceG.Pose()
pose_Place_0 = placeG.Pose()
aprox_placeG_0 = aprox_placeG.Pose()

for k in range(altura):
    for i in range(filas):
        for j in range(columnas):
            offset = robomath.transl(j * paso_x, i * paso_y, k * paso_z)
            preplaceG.setPose(pose_PrePlace_0 * offset)
            placeG.setPose(pose_Place_0 * offset)
            aprox_placeG.setPose(aprox_placeG_0 * offset)

            robot.MoveJ(aprox_pickG)
            robot.MoveJ(prepickG)
            robot.MoveL(pickG)
            robot.MoveL(prepickG)
            robot.MoveJ(aprox_pickG)

            robot.MoveJ(aprox_placeG)
            robot.MoveJ(preplaceG)
            robot.MoveL(placeG)
            robot.MoveL(preplaceG)
            robot.MoveJ(aprox_placeG)

preplaceG.setPose(pose_PrePlace_0)
placeG.setPose(pose_Place_0)
aprox_placeG.setPose(aprox_placeG_0)
robot.MoveJ(reposoG)
