"""
Comprueba .env, PostgreSQL y MQTT. Ejecutar en la carpeta del proyecto:
  python diagnostico.py
"""

import os
import ssl
import sys
from pathlib import Path
from urllib.parse import urlparse

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
load_dotenv(ROOT / ".env")

OK = "OK"
FAIL = "FALLO"


def linea(estado: str, texto: str) -> None:
    print(f"[{estado}] {texto}")


def comprobar_env() -> bool:
    print("\n=== 1. Archivo .env ===")
    env_path = ROOT / ".env"
    if not env_path.is_file():
        linea(FAIL, "No existe .env en esta carpeta.")
        print("    Solucion: copy .env.example .env  y edita PGPASSWORD y PGDATABASE")
        return False
    linea(OK, f".env encontrado: {env_path}")

    campos = {
        "MQTT_URL": os.getenv("MQTT_URL"),
        "MQTT_USERNAME": os.getenv("MQTT_USERNAME"),
        "MQTT_PASSWORD": os.getenv("MQTT_PASSWORD"),
        "PGHOST": os.getenv("PGHOST"),
        "PGPORT": os.getenv("PGPORT"),
        "PGUSER": os.getenv("PGUSER"),
        "PGPASSWORD": os.getenv("PGPASSWORD"),
        "PGDATABASE": os.getenv("PGDATABASE"),
    }
    bien = True
    for nombre, valor in campos.items():
        if not valor:
            linea(FAIL, f"{nombre} vacio en .env")
            bien = False
        elif "PASSWORD" in nombre:
            linea(OK, f"{nombre}=*** ({len(valor)} caracteres)")
        else:
            linea(OK, f"{nombre}={valor}")
    return bien


def comprobar_postgres() -> bool:
    print("\n=== 2. PostgreSQL ===")
    try:
        import pg8000
    except ImportError:
        linea(FAIL, "Falta pg8000. Ejecuta: python -m pip install pg8000")
        return False

    host = os.getenv("PGHOST", "localhost")
    port = int(os.getenv("PGPORT", "5432"))
    user = os.getenv("PGUSER", "postgres")
    password = os.getenv("PGPASSWORD", "")
    database = os.getenv("PGDATABASE", "postgres")

    try:
        conn = pg8000.connect(
            user=user, password=password, host=host, port=port, database=database
        )
    except Exception as ex:
        linea(FAIL, f"No conecta a la BD: {ex}")
        print("    Revisa: PostgreSQL instalado, servicio iniciado, PGPASSWORD, PGDATABASE")
        return False

    linea(OK, f"Conectado a '{database}' en {host}:{port}")

    cur = conn.cursor()
    tablas = ("clientes", "pedidos", "stock_sabores", "sabores", "envios", "cuentas_bancarias")
    faltan = []
    for tabla in tablas:
        cur.execute(
            """
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = 'public' AND table_name = %s
            """,
            (tabla,),
        )
        if cur.fetchone():
            linea(OK, f"Tabla public.{tabla} existe")
        else:
            linea(FAIL, f"Falta tabla public.{tabla}")
            faltan.append(tabla)

    cur.close()
    conn.close()

    if faltan:
        print("    Solucion: importar el SQL del proyecto en pgAdmin (Query Tool en PLanta_PR2)")
        return False
    return True


def comprobar_mqtt() -> bool:
    print("\n=== 3. MQTT (EMQX) ===")
    try:
        import certifi
        from paho.mqtt import client as mqtt_client
        from paho.mqtt.enums import CallbackAPIVersion
    except ImportError:
        linea(FAIL, "Faltan paho-mqtt o certifi. Ejecuta: python -m pip install paho-mqtt certifi")
        return False

    url = os.getenv("MQTT_URL", "")
    user = os.getenv("MQTT_USERNAME", "")
    password = os.getenv("MQTT_PASSWORD", "")
    if not url or not user or not password:
        linea(FAIL, "MQTT_URL / usuario / password vacios en .env")
        return False

    u = urlparse(url)
    host = u.hostname or ""
    scheme = (u.scheme or "mqtt").lower()
    port = u.port or (443 if scheme in ("wss", "https") else 8883)
    path = u.path or "/mqtt"
    if not path.startswith("/"):
        path = "/" + path
    use_ws = scheme in ("ws", "wss", "http", "https")
    use_tls = scheme in ("mqtts", "wss", "https", "ssl")

    resultado = {"ok": False, "error": ""}

    def on_connect(client, userdata, flags, reason_code, properties=None):
        if getattr(reason_code, "is_failure", False):
            resultado["error"] = str(reason_code)
        else:
            resultado["ok"] = True
        client.disconnect()

    cid = "diagnostico_" + str(os.getpid())
    cli = mqtt_client.Client(
        callback_api_version=CallbackAPIVersion.VERSION2,
        client_id=cid,
        transport="websockets" if use_ws else "tcp",
    )
    if use_ws:
        cli.ws_set_options(path=path)
    if use_tls:
        cli.tls_set(ca_certs=certifi.where(), cert_reqs=ssl.CERT_REQUIRED)
    cli.username_pw_set(user, password)
    cli.on_connect = on_connect

    try:
        cli.connect(host, port, keepalive=30)
        cli.loop_start()
        for _ in range(50):
            if resultado["ok"] or resultado["error"]:
                break
            import time

            time.sleep(0.2)
        cli.loop_stop()
    except Exception as ex:
        linea(FAIL, f"No llega al broker: {ex}")
        print("    Prueba otra red (hotspot). El instituto a veces bloquea el puerto", port)
        return False

    if resultado["ok"]:
        linea(OK, f"MQTT conectado a {host}:{port}{path}")
        return True

    linea(FAIL, f"MQTT rechazado: {resultado['error'] or 'timeout'}")
    print("    Revisa usuario/contraseña en EMQX Cloud")
    return False


def comprobar_proyectos_mqtt() -> bool:
    print("\n=== 4. MQTT Proyectos (UPV) ===")
    try:
        from paho.mqtt import client as mqtt_client
        from paho.mqtt.enums import CallbackAPIVersion
    except ImportError:
        linea(FAIL, "Falta paho-mqtt")
        return False

    host = os.getenv("PROYECTOS_MQTT_HOST", "mqtt.dsic.upv.es")
    port = int(os.getenv("PROYECTOS_MQTT_PORT", "1883"))
    user = os.getenv("PROYECTOS_MQTT_USERNAME", "giirob")
    password = os.getenv("PROYECTOS_MQTT_PASSWORD", "")

    resultado: dict = {"ok": False, "error": None}

    def on_connect(client, userdata, flags, reason_code, properties=None):
        if getattr(reason_code, "is_failure", False):
            resultado["error"] = str(reason_code)
        else:
            resultado["ok"] = True
        client.disconnect()

    cid = "diag_proyectos_" + str(os.getpid())
    cli = mqtt_client.Client(
        callback_api_version=CallbackAPIVersion.VERSION2,
        client_id=cid,
    )
    cli.username_pw_set(user, password)
    cli.on_connect = on_connect
    try:
        cli.connect(host, port, keepalive=10)
        cli.loop_start()
        import time

        for _ in range(50):
            if resultado["ok"] or resultado["error"]:
                break
            time.sleep(0.1)
        cli.loop_stop()
    except Exception as ex:
        linea(FAIL, f"No se pudo conectar a {host}:{port}: {ex}")
        return False

    if resultado["ok"]:
        linea(OK, f"Proyectos MQTT OK ({host}:{port})")
        return True
    linea(FAIL, f"Proyectos rechazado: {resultado['error'] or 'timeout'}")
    return False


def main() -> None:
    print("Diagnostico Proyecto PR2")
    print("Carpeta:", ROOT)
    env_ok = comprobar_env()
    pg_ok = comprobar_postgres() if env_ok else False
    mqtt_ok = comprobar_mqtt() if env_ok else False

    print("\n=== RESUMEN ===")
    proyectos_ok = False
    if env_ok and os.getenv("PROYECTOS_MQTT_PASSWORD"):
        proyectos_ok = comprobar_proyectos_mqtt()

    if env_ok and pg_ok and mqtt_ok:
        print("Todo correcto. Puedes ejecutar:")
        print("  python mqtt_bridge.py          (pedidos web -> BD)")
        if proyectos_ok:
            print("  python mqtt_station_relay.py   (numero estacion -> UPV)")
        elif not os.getenv("PROYECTOS_MQTT_PASSWORD"):
            print("  (opcional) Rellena PROYECTOS_MQTT_PASSWORD y ejecuta mqtt_station_relay.py")
        sys.exit(0)
    if not env_ok:
        print("- Arregla el archivo .env")
    if env_ok and not pg_ok:
        print("- Arregla PostgreSQL (contraseña, nombre BD, tablas SQL)")
    if env_ok and not mqtt_ok:
        print("- Arregla MQTT (red, credenciales EMQX)")
    print("\nManda captura de esta pantalla si sigue fallando.")
    sys.exit(1)


if __name__ == "__main__":
    main()
