"""
Puente: Web (MQTT) -> PostgreSQL.

La pagina publica JSON en el tema tienda/pedido/nuevo; este script lo guarda en tablas
clientes, pedidos, lineas_pedido, envios y actualiza stock_sabores. Si falta stock,
publica tienda/stock/alerta y no graba nada.

Ejecutar:
  cd Proyecto_final_pr2
  python -m pip install -r requirements.txt
  copia .env.example a .env y rellena MQTT y Postgres
  python mqtt_bridge.py
  python mqtt_station_relay.py   # status (Chocolatillo) -> command (UPV)

Dependencias: pg8000, paho-mqtt, python-dotenv, certifi (MQTT por WSS).
"""

import hashlib
import json
import os
import random
import re
import ssl
import string
import unicodedata
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

import certifi
import pg8000
from dotenv import load_dotenv
from paho.mqtt import client as mqtt_client
from paho.mqtt.enums import CallbackAPIVersion

load_dotenv()

MQTT_URL = os.getenv("MQTT_URL", "")
MQTT_USERNAME = os.getenv("MQTT_USERNAME", "")
MQTT_PASSWORD = os.getenv("MQTT_PASSWORD", "")
MQTT_TOPIC = os.getenv("MQTT_TOPIC", "tienda/pedido/nuevo")
MQTT_TOPIC_CUENTA = os.getenv("MQTT_TOPIC_CUENTA", "tienda/cuenta/actualizada")
MQTT_TOPIC_EMPRESAS_LISTA = os.getenv(
    "MQTT_TOPIC_EMPRESAS_LISTA", "tienda/empresas_reparto/lista"
)
MQTT_TOPIC_EMPRESAS_SOLICITAR = os.getenv(
    "MQTT_TOPIC_EMPRESAS_SOLICITAR", "tienda/empresas_reparto/solicitar"
)
LOGISTICA_TOPIC_PREFIX = os.getenv("LOGISTICA_TOPIC_PREFIX", "logistica")
EMPRESA_REPARTO_ID = os.getenv("EMPRESA_REPARTO_ID")
# Aviso opcional para ESP32 / planta (mismo broker)
FABRICA_TOPIC = os.getenv("FABRICA_TOPIC", "fabrica/esp32/pedido_guardado")
NUMERO_COMBI_TOPIC = os.getenv("NUMERO_COMBI_TOPIC", "numero_combi/asignado")
# Mismo numero que numero_combi (solo el entero, para estacion/demo)
STATION_STATUS_TOPIC = os.getenv("STATION_STATUS_TOPIC", "giirob/pr2/station/demo/status")

PGHOST = os.getenv("PGHOST", "localhost")
PGPORT = int(os.getenv("PGPORT", "5432"))
PGUSER = os.getenv("PGUSER", "postgres")
PGPASSWORD = os.getenv("PGPASSWORD", "")
PGDATABASE = os.getenv("PGDATABASE", "postgres")

SABORES_ORDENADOS = ("chocolate", "caramelo", "avellana")
SABOR_ALIAS = {
    "1": "chocolate",
    "2": "caramelo",
    "3": "avellana",
    "chocolate negro 70%": "chocolate",
    "chocolate negro": "chocolate",
    "chocolate": "chocolate",
    "caramelo salado": "caramelo",
    "caramelo": "caramelo",
    "chocolate con leche": "caramelo",
    "avellana praline": "avellana",
    "avellama praline": "avellana",
    "avellana": "avellana",
    "chocolate blanco": "avellana",
}

# IDs en stock_sabores (sabores de la BD: 1=negro, 2=leche, 3=blanco)
STOCK_ID_POR_CANON: Dict[str, int] = {
    "chocolate": 1,
    "caramelo": 2,
    "avellana": 3,
}

# Arbol de combinaciones (CHO/CAR/AVE) alineado con tablaHash del PR2.
SABOR_A_CODIGO = {"chocolate": "CHO", "caramelo": "CAR", "avellana": "AVE"}
CODIGO_A_SABOR = {"CHO": "chocolate", "CAR": "caramelo", "AVE": "avellana"}

RUTA_A_NUMERO: Dict[str, int] = {
    "CHO": 1,
    "CAR": 2,
    "AVE": 3,
    "CHO-CHO": 4,
    "CHO-CAR": 5,
    "CHO-AVE": 6,
    "CAR-CAR": 7,
    "CAR-AVE": 8,
    "AVE-AVE": 9,
    "CHO-CHO-CHO": 10,
    "CHO-CHO-CAR": 11,
    "CHO-CHO-AVE": 12,
    "CHO-CAR-CAR": 13,
    "CHO-CAR-AVE": 14,
    "CHO-AVE-AVE": 15,
    "CAR-CAR-CAR": 16,
    "CAR-CAR-AVE": 17,
    "CAR-AVE-AVE": 18,
    "AVE-AVE-AVE": 19,
    "CHO-CHO-CHO-CHO": 20,
    "CHO-CHO-CHO-CAR": 21,
    "CHO-CHO-CHO-AVE": 22,
    "CHO-CHO-AVE-AVE": 23,
    "CHO-CHO-CAR-AVE": 24,
    "CHO-CHO-CAR-CAR": 25,
    "CHO-CAR-CAR-CAR": 26,
    "CHO-CAR-CAR-AVE": 27,
    "CHO-CAR-AVE-AVE": 28,
    "CHO-AVE-AVE-AVE": 29,
    "CAR-CAR-CAR-CAR": 30,
    "CAR-CAR-CAR-AVE": 31,
    "CAR-CAR-AVE-AVE": 32,
    "CAR-AVE-AVE-AVE": 33,
    "AVE-AVE-AVE-AVE": 34,
}

COMBINACION_A_NUMERO: Dict[Tuple[str, ...], int] = {}
NUMERO_A_COMBINACION: Dict[int, Tuple[str, ...]] = {}
for _ruta, _numero in RUTA_A_NUMERO.items():
    _combo = tuple(CODIGO_A_SABOR[c] for c in _ruta.split("-"))
    COMBINACION_A_NUMERO[_combo] = _numero
    NUMERO_A_COMBINACION[_numero] = _combo


def combo_a_ruta(combo: Tuple[str, ...]) -> str:
    return "-".join(SABOR_A_CODIGO[s] for s in combo)


def comprobar_variables_mqtt() -> None:
    if not MQTT_URL or not MQTT_USERNAME or not MQTT_PASSWORD:
        raise SystemExit("Faltan MQTT_URL, MQTT_USERNAME o MQTT_PASSWORD en .env")


# --- Utilidades de texto / MQTT ---------------------------------------------

def normalizar_nombre_sabor(nombre: str) -> str:
    s = (nombre or "").lower()
    s = unicodedata.normalize("NFD", s)
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.strip()


def tipo_pedido_desde_carrito(productos: List[Any]) -> str:
    """
    Si en el carrito hay alguna linea 'industrial', el pedido es industrial.
    (La web ya limita cajas; antes se exigian >=5 cajas y con maximo 4 nunca marcaba bien.)
    """
    if not isinstance(productos, list) or not productos:
        return "personalizado"
    for item in productos:
        if isinstance(item, dict) and item.get("tipo") == "industrial":
            return "industrial"
    return "personalizado"


def _normalizar_sabor_para_combinacion(raw: Any) -> Optional[str]:
    nombre = normalizar_nombre_sabor(str(raw or ""))
    return SABOR_ALIAS.get(nombre)


def _extraer_cajas_por_sabor_industrial(productos: List[Any]) -> Dict[str, int]:
    out = {s: 0 for s in SABORES_ORDENADOS}
    if not isinstance(productos, list):
        return out
    for item in productos:
        if not isinstance(item, dict) or item.get("tipo") != "industrial":
            continue
        det = item.get("detalles")
        if not isinstance(det, dict):
            continue
        for sabor_raw, cajas_raw in det.items():
            sabor = _normalizar_sabor_para_combinacion(sabor_raw)
            if not sabor:
                continue
            cajas = int(cajas_raw) if cajas_raw is not None else 0
            if cajas > 0:
                out[sabor] += cajas
    return out


def obtener_numero_combinacion(productos: List[Any], tipo_pedido: str) -> Optional[Dict[str, Any]]:
    """
    Devuelve el numero de combinacion para pedidos industriales de 1..4 cajas.
    Se representa como multiconjunto ordenado (ej. chocolate, chocolate, caramelo).
    """
    if tipo_pedido != "industrial":
        return None
    cajas_por_sabor = _extraer_cajas_por_sabor_industrial(productos)
    total_cajas = sum(cajas_por_sabor.values())
    if total_cajas <= 0:
        return None
    if total_cajas > 4:
        # El front limita a 4. Si llega mas, no se calcula combinacion cerrada.
        return None
    combo: List[str] = []
    for sabor in SABORES_ORDENADOS:
        combo.extend([sabor] * cajas_por_sabor[sabor])
    combo_tuple = tuple(combo)
    numero = COMBINACION_A_NUMERO.get(combo_tuple)
    if not numero:
        return None
    return {
        "numero": numero,
        "ruta": combo_a_ruta(combo_tuple),
        "tamano": total_cajas,
        "sabores": list(combo_tuple),
        "conteo": cajas_por_sabor,
    }


def asegurar_tablas_combinaciones(conn) -> None:
    """
    Crea un "arbol" persistente de combinaciones y una tabla de relacion pedido->combinacion.
    """
    cur = conn.cursor()
    try:
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS public.arbol_combinaciones (
                numero_combi integer PRIMARY KEY,
                tamano integer NOT NULL CHECK (tamano BETWEEN 1 AND 4),
                sabor_1 varchar(30) NOT NULL,
                sabor_2 varchar(30),
                sabor_3 varchar(30),
                sabor_4 varchar(30),
                ruta varchar(200) NOT NULL UNIQUE
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS public.pedidos_combinacion (
                id_pedido integer PRIMARY KEY REFERENCES public.pedidos(id_pedido) ON DELETE CASCADE,
                numero_combi integer NOT NULL REFERENCES public.arbol_combinaciones(numero_combi),
                tamano integer NOT NULL CHECK (tamano BETWEEN 1 AND 4),
                sabores_json text NOT NULL,
                fecha_registro timestamp without time zone DEFAULT now() NOT NULL
            )
            """
        )
        for numero in sorted(NUMERO_A_COMBINACION):
            combo = NUMERO_A_COMBINACION[numero]
            codigos = [SABOR_A_CODIGO[s] for s in combo] + [None] * (4 - len(combo))
            ruta = combo_a_ruta(combo)
            cur.execute(
                """
                INSERT INTO public.arbol_combinaciones
                  (numero_combi, tamano, sabor_1, sabor_2, sabor_3, sabor_4, ruta)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (numero_combi) DO UPDATE SET
                  tamano = EXCLUDED.tamano,
                  sabor_1 = EXCLUDED.sabor_1,
                  sabor_2 = EXCLUDED.sabor_2,
                  sabor_3 = EXCLUDED.sabor_3,
                  sabor_4 = EXCLUDED.sabor_4,
                  ruta = EXCLUDED.ruta
                """,
                (numero, len(combo), codigos[0], codigos[1], codigos[2], codigos[3], ruta),
            )
        conn.commit()
    finally:
        cur.close()


def asegurar_columnas_cliente(conn) -> None:
    """Columnas de direcciones y forma juridica en clientes."""
    cur = conn.cursor()
    try:
        cur.execute(
            """
            ALTER TABLE public.clientes
              ADD COLUMN IF NOT EXISTS direccion_envio TEXT,
              ADD COLUMN IF NOT EXISTS codigo_postal VARCHAR(10),
              ADD COLUMN IF NOT EXISTS direccion_fiscal TEXT,
              ADD COLUMN IF NOT EXISTS codigo_postal_fiscal VARCHAR(10),
              ADD COLUMN IF NOT EXISTS forma_juridica VARCHAR(20)
            """
        )
        conn.commit()
    finally:
        cur.close()


def asegurar_esquema_cuentas_bancarias(conn) -> None:
    """
    Tabla cuentas_bancarias alineada con sql/cuentas_bancarias.sql.
    Si la tabla es antigua (sin iban), anade columnas sin borrar datos.
    """
    cur = conn.cursor()
    try:
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS public.cuentas_bancarias (
              id_cuenta SERIAL PRIMARY KEY,
              id_cliente INTEGER NOT NULL
                REFERENCES public.clientes (id_cliente) ON DELETE CASCADE,
              tipo_metodo VARCHAR(20) NOT NULL DEFAULT 'tarjeta',
              numero_cuenta VARCHAR(19),
              cvv VARCHAR(4),
              fecha_caducidad VARCHAR(7),
              iban VARCHAR(34),
              titular_cuenta VARCHAR(120),
              concepto_pago VARCHAR(200),
              es_principal BOOLEAN NOT NULL DEFAULT TRUE,
              activa BOOLEAN NOT NULL DEFAULT TRUE,
              fecha_registro TIMESTAMPTZ NOT NULL DEFAULT NOW(),
              fecha_actualizacion TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            """
        )
        cur.execute(
            """
            ALTER TABLE public.cuentas_bancarias
              ADD COLUMN IF NOT EXISTS tipo_metodo VARCHAR(20),
              ADD COLUMN IF NOT EXISTS numero_cuenta VARCHAR(19),
              ADD COLUMN IF NOT EXISTS cvv VARCHAR(4),
              ADD COLUMN IF NOT EXISTS fecha_caducidad VARCHAR(7),
              ADD COLUMN IF NOT EXISTS iban VARCHAR(34),
              ADD COLUMN IF NOT EXISTS titular_cuenta VARCHAR(120),
              ADD COLUMN IF NOT EXISTS concepto_pago VARCHAR(200),
              ADD COLUMN IF NOT EXISTS es_principal BOOLEAN DEFAULT TRUE,
              ADD COLUMN IF NOT EXISTS activa BOOLEAN DEFAULT TRUE,
              ADD COLUMN IF NOT EXISTS fecha_registro TIMESTAMPTZ DEFAULT NOW(),
              ADD COLUMN IF NOT EXISTS fecha_actualizacion TIMESTAMPTZ DEFAULT NOW()
            """
        )
        conn.commit()
        print("Esquema cuentas_bancarias OK (columnas iban/tarjeta)")
    finally:
        cur.close()


def extraer_resumen_pedido(productos: List[Any]) -> Dict[str, Any]:
    """Cajas grandes y detalle legible por tipo de pedido."""
    numero_cajas = contar_cajas_grandes(productos)
    sabores: List[str] = []
    detalle_industrial: List[Dict[str, Any]] = []
    detalle_personalizado: List[Dict[str, Any]] = []
    if not isinstance(productos, list):
        return {
            "numeroCajas": numero_cajas,
            "sabores": sabores,
            "detalleIndustrial": detalle_industrial,
            "detallePersonalizado": detalle_personalizado,
        }
    for item in productos:
        if not isinstance(item, dict):
            continue
        det = item.get("detalles")
        if not isinstance(det, dict):
            continue
        if item.get("tipo") == "industrial":
            for nombre, cajas in det.items():
                c = int(cajas or 0)
                if c > 0:
                    sabores.append(f"{nombre}: {c} caja(s) grande(s)")
                    detalle_industrial.append({"sabor": nombre, "cajasGrandes": c})
        else:
            cajas_grandes = int(item.get("cajas") or 0)
            for nombre, cajitas in det.items():
                c = int(cajitas or 0)
                if c > 0:
                    sabores.append(f"{nombre}: {c} cajita(s)")
            detalle_personalizado.append(
                {
                    "cajasGrandes": cajas_grandes,
                    "composicion": det,
                    "descripcion": item.get("descripcion"),
                }
            )
    return {
        "numeroCajas": numero_cajas,
        "sabores": sabores,
        "detalleIndustrial": detalle_industrial,
        "detallePersonalizado": detalle_personalizado,
    }


def contar_cajas_grandes(productos: List[Any]) -> int:
    if not isinstance(productos, list):
        return 1
    total = 0
    for item in productos:
        if not isinstance(item, dict):
            continue
        if item.get("tipo") == "industrial":
            det = item.get("detalles")
            if isinstance(det, dict):
                for v in det.values():
                    total += int(v) if v is not None else 0
        elif item.get("tipo") == "personalizado":
            total += int(item.get("cajas") or 0)
    return total if total > 0 else 1


def extraer_lineas_pedido(productos: List[Any]) -> List[Dict[str, Any]]:
    """
    Une todas las lineas del carrito en cantidades por nombre de sabor.
    - Industrial: detalles = cajas grandes por sabor; cada una son 48 cajitas -> multiplicamos por 48.
    - Personalizado: detalles = cajitas por sabor (factor 1).
    Las cantidades deben coincidir con lo que guardais en stock_sabores.stock_paquetes.
    """
    acumulado: Dict[str, int] = {}
    if not isinstance(productos, list):
        return []
    for item in productos:
        if not isinstance(item, dict):
            continue
        det = item.get("detalles")
        if not isinstance(det, dict):
            continue
        factor = 48 if item.get("tipo") == "industrial" else 1
        for nombre, cantidad in det.items():
            qty = (int(cantidad) if cantidad is not None else 0) * factor
            if qty <= 0:
                continue
            key = str(nombre)
            acumulado[key] = acumulado.get(key, 0) + qty
    return [{"nombre": nombre, "cantidad": cantidad} for nombre, cantidad in acumulado.items()]


def get_or_create_sabor(cur, nombre_sabor: Any) -> int:
    """
    Resuelve el id_sabor de stock. La web usa nombres largos (Chocolate Negro 70%…)
    pero stock_sabores está en ids 1–3; se mapea por SABOR_ALIAS, no por texto literal.
    """
    referencia = str(nombre_sabor or "").strip()
    if re.fullmatch(r"\d+", referencia):
        sid = int(referencia)
        cur.execute(
            "SELECT id_sabor FROM public.sabores WHERE id_sabor = %s LIMIT 1",
            (sid,),
        )
        row = cur.fetchone()
        if row:
            return row[0]
        raise ValueError(f"Sabor con id {sid} no existe en BD")

    canon = _normalizar_sabor_para_combinacion(referencia)
    if canon and canon in STOCK_ID_POR_CANON:
        sid = STOCK_ID_POR_CANON[canon]
        cur.execute(
            "SELECT id_sabor FROM public.sabores WHERE id_sabor = %s LIMIT 1",
            (sid,),
        )
        if cur.fetchone():
            return sid

    buscado = normalizar_nombre_sabor(referencia)
    alias = SABOR_ALIAS.get(buscado)
    if alias and alias in STOCK_ID_POR_CANON:
        return STOCK_ID_POR_CANON[alias]

    cur.execute(
        "SELECT id_sabor FROM public.sabores WHERE lower(nombre) = %s LIMIT 1",
        (buscado,),
    )
    row = cur.fetchone()
    if row:
        return row[0]

    cur.execute(
        "INSERT INTO public.sabores (nombre, activo) VALUES (%s, true) RETURNING id_sabor",
        (str(nombre_sabor),),
    )
    nuevo = cur.fetchone()[0]
    cur.execute(
        """
        INSERT INTO public.stock_sabores (id_sabor, stock_paquetes, stock_minimo)
        VALUES (%s, 0, 0)
        ON CONFLICT (id_sabor) DO NOTHING
        """,
        (nuevo,),
    )
    return nuevo


def validar_stock_disponible(cur, lineas: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = []
    for linea in lineas:
        id_sabor = get_or_create_sabor(cur, linea["nombre"])
        cur.execute(
            "SELECT stock_paquetes FROM public.stock_sabores WHERE id_sabor = %s LIMIT 1",
            (id_sabor,),
        )
        row = cur.fetchone()
        stock_actual = int(row[0]) if row else 0
        pedido = int(linea["cantidad"] or 0)
        if stock_actual < pedido:
            out.append(
                {
                    "idSabor": id_sabor,
                    "sabor": linea["nombre"],
                    "pedido": pedido,
                    "stock": stock_actual,
                }
            )
    return out


def descontar_stock(cur, lineas: List[Dict[str, Any]]) -> None:
    for linea in lineas:
        id_sabor = get_or_create_sabor(cur, linea["nombre"])
        cur.execute(
            """
            UPDATE public.stock_sabores
            SET stock_paquetes = stock_paquetes - %s,
                fecha_actualizacion = now()
            WHERE id_sabor = %s
            """,
            (linea["cantidad"], id_sabor),
        )


def normalizar_cliente_web(cliente: Dict[str, Any]) -> Dict[str, Any]:
    """
    Formato Mi cuenta (autonomo/empresa) o legacy {nombre, telefono, direccion}.
    """
    if not isinstance(cliente, dict):
        cliente = {}
    nombre = (cliente.get("nombre") or cliente.get("nombreApellidos") or "").strip()
    telefono = (cliente.get("telefono") or "").strip()
    email = (cliente.get("email") or cliente.get("correo") or "").strip()
    cif = (cliente.get("cif") or "").strip()
    tipo = (cliente.get("tipo") or cliente.get("tipoCliente") or "autonomo").strip().lower()
    if tipo not in ("autonomo", "empresa"):
        tipo = "autonomo"
    forma_juridica = (cliente.get("formaJuridica") or "").strip().upper()
    if tipo == "empresa" and forma_juridica not in ("SL", "SA"):
        forma_juridica = "SL"
    if tipo == "autonomo":
        forma_juridica = "autonomo"
    empresa = (cliente.get("empresa") or cliente.get("nombreEmpresa") or "").strip()
    departamento = (cliente.get("departamento") or "").strip()

    dir_env = (cliente.get("direccionEnvio") or "").strip()
    cp_env = (cliente.get("codigoPostal") or cliente.get("codigoPostalEnvio") or "").strip()
    dir_fiscal = (cliente.get("direccionFiscal") or "").strip()
    cp_fiscal = (cliente.get("codigoPostalFiscal") or "").strip()

    direccion = (cliente.get("direccion") or "").strip()
    if not direccion:
        if dir_env and cp_env:
            direccion = f"{dir_env}, CP {cp_env}"
        elif dir_env:
            direccion = dir_env
        elif cp_env:
            direccion = f"CP {cp_env}"
    if not direccion and tipo == "empresa":
        direccion = " · ".join(x for x in (empresa, departamento) if x) or "Sin direccion"

    pago_raw = cliente.get("pago")
    if not isinstance(pago_raw, dict):
        pago_raw = {}
    pago: Dict[str, Any] = {}
    if tipo == "autonomo":
        pago = {
            "numCuenta": (cliente.get("numCuenta") or pago_raw.get("numCuenta") or "").strip(),
            "cvv": (cliente.get("cvv") or pago_raw.get("cvv") or "").strip(),
            "fechaCad": (cliente.get("fechaCad") or pago_raw.get("fechaCad") or "").strip(),
        }
    else:
        pago = {
            "iban": (cliente.get("iban") or pago_raw.get("iban") or "").strip(),
            "titularCuenta": (
                cliente.get("titularCuenta") or pago_raw.get("titularCuenta") or ""
            ).strip(),
            "concepto": (cliente.get("concepto") or pago_raw.get("concepto") or "").strip(),
        }

    return {
        "nombre": nombre,
        "telefono": telefono,
        "direccion": direccion,
        "direccionEnvio": dir_env,
        "codigoPostal": cp_env,
        "direccionFiscal": dir_fiscal,
        "codigoPostalFiscal": cp_fiscal,
        "email": email,
        "cif": cif,
        "tipo": tipo,
        "formaJuridica": forma_juridica,
        "empresa": empresa,
        "departamento": departamento,
        "pago": pago,
        "tarjetas": extraer_tarjetas_autonomo(cliente),
    }


def extraer_tarjetas_autonomo(cliente: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Lista de tarjetas desde Mi cuenta (varias) o un solo bloque pago legacy."""
    if not isinstance(cliente, dict):
        return []
    tarjetas_raw = cliente.get("tarjetas")
    out: List[Dict[str, Any]] = []
    if isinstance(tarjetas_raw, list):
        for item in tarjetas_raw:
            if not isinstance(item, dict):
                continue
            numero = (item.get("numCuenta") or item.get("numero_cuenta") or "").strip()
            cvv = (item.get("cvv") or "").strip()
            fecha = (item.get("fechaCad") or item.get("fecha_caducidad") or "").strip()
            if not numero or not cvv or not fecha:
                continue
            out.append(
                {
                    "numCuenta": numero,
                    "cvv": cvv,
                    "fechaCad": fecha,
                    "esPrincipal": bool(item.get("esPrincipal") or item.get("es_principal")),
                }
            )
    if out:
        if not any(t["esPrincipal"] for t in out):
            out[0]["esPrincipal"] = True
        return out

    pago_raw = cliente.get("pago")
    if not isinstance(pago_raw, dict):
        pago_raw = {}
    numero = (cliente.get("numCuenta") or pago_raw.get("numCuenta") or "").strip()
    cvv = (cliente.get("cvv") or pago_raw.get("cvv") or "").strip()
    fecha = (cliente.get("fechaCad") or pago_raw.get("fechaCad") or "").strip()
    if numero and cvv and fecha:
        return [{"numCuenta": numero, "cvv": cvv, "fechaCad": fecha, "esPrincipal": True}]
    return []


def get_or_create_cliente(cur, cliente: Dict[str, Any]) -> int:
    """CIF real de la web si existe; si no, WEB-xxxxx por hash."""
    c = normalizar_cliente_web(cliente)
    nombre = c["nombre"]
    telefono = c["telefono"]
    direccion = c["direccion"]
    dir_env = c["direccionEnvio"]
    cp_env = c["codigoPostal"]
    dir_fiscal = c["direccionFiscal"]
    cp_fiscal = c["codigoPostalFiscal"]
    if not nombre or not telefono or not direccion:
        raise ValueError("Datos de cliente incompletos (nombre, telefono, direccion)")
    if not dir_env or not cp_env:
        raise ValueError("Faltan direccion de envio o codigo postal")
    if not dir_fiscal or not cp_fiscal:
        raise ValueError("Faltan direccion fiscal o codigo postal fiscal")

    if c["cif"]:
        cif_db = c["cif"]
    else:
        digest = hashlib.md5(f"{nombre}|{telefono}|{direccion}".encode("utf-8")).hexdigest()[:12].upper()
        cif_db = f"WEB-{digest}"

    tipo_cliente = "empresa" if c["tipo"] == "empresa" else "autonomo"
    nombre_empresa = c["empresa"] if c["tipo"] == "empresa" else nombre
    correo = c["email"] or None
    forma_juridica = c.get("formaJuridica") or ("autonomo" if tipo_cliente == "autonomo" else "SL")

    cur.execute("SELECT id_cliente FROM public.clientes WHERE cif = %s LIMIT 1", (cif_db,))
    row = cur.fetchone()
    if row:
        id_cliente = row[0]
        cur.execute(
            """
            UPDATE public.clientes
            SET nombre = %s, telefono = %s, direccion = %s, nombre_empresa = %s,
                tipo_cliente = %s, correo = %s, direccion_envio = %s, codigo_postal = %s,
                direccion_fiscal = %s, codigo_postal_fiscal = %s, forma_juridica = %s
            WHERE id_cliente = %s
            """,
            (
                nombre,
                telefono,
                direccion,
                nombre_empresa,
                tipo_cliente,
                correo,
                dir_env,
                cp_env,
                dir_fiscal,
                cp_fiscal,
                forma_juridica,
                id_cliente,
            ),
        )
        return id_cliente

    cur.execute(
        """
        INSERT INTO public.clientes
          (tipo_cliente, nombre, cif, telefono, correo, nombre_empresa, direccion,
           direccion_envio, codigo_postal, direccion_fiscal, codigo_postal_fiscal, forma_juridica)
        VALUES
          (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING id_cliente
        """,
        (
            tipo_cliente,
            nombre,
            cif_db,
            telefono,
            correo,
            nombre_empresa,
            direccion,
            dir_env,
            cp_env,
            dir_fiscal,
            cp_fiscal,
            forma_juridica,
        ),
    )
    return cur.fetchone()[0]


def _upsert_tarjeta_autonomo(
    cur,
    id_cliente: int,
    numero: str,
    cvv: str,
    fecha_cad: str,
    es_principal: bool,
) -> None:
    cur.execute(
        """
        SELECT id_cuenta FROM public.cuentas_bancarias
        WHERE id_cliente = %s AND tipo_metodo = 'tarjeta'
          AND numero_cuenta = %s AND activa = TRUE
        LIMIT 1
        """,
        (id_cliente, numero),
    )
    existente = cur.fetchone()
    if existente:
        cur.execute(
            """
            UPDATE public.cuentas_bancarias
            SET cvv = %s, fecha_caducidad = %s, es_principal = %s,
                fecha_actualizacion = NOW()
            WHERE id_cuenta = %s
            """,
            (cvv, fecha_cad, es_principal, existente[0]),
        )
    else:
        cur.execute(
            """
            INSERT INTO public.cuentas_bancarias
              (id_cliente, tipo_metodo, numero_cuenta, cvv, fecha_caducidad, es_principal)
            VALUES (%s, 'tarjeta', %s, %s, %s, %s)
            """,
            (id_cliente, numero, cvv, fecha_cad, es_principal),
        )


def guardar_cuenta_bancaria(cur, id_cliente: int, cliente: Dict[str, Any]) -> None:
    """
    Persiste datos de pago de Mi cuenta en public.cuentas_bancarias.
    Empresa: una sola cuenta (UPDATE o INSERT). Autonomo: todas las tarjetas de la web.
    """
    c = normalizar_cliente_web(cliente)
    pago = c.get("pago") or {}
    cur.execute(
        "SELECT tipo_cliente FROM public.clientes WHERE id_cliente = %s",
        (id_cliente,),
    )
    row = cur.fetchone()
    if not row:
        return
    tipo_cliente = row[0]

    if tipo_cliente == "empresa":
        iban = (pago.get("iban") or "").strip()
        titular = (pago.get("titularCuenta") or "").strip()
        concepto = (pago.get("concepto") or "").strip()
        if not iban or not titular or not concepto:
            return
        cur.execute(
            """
            SELECT id_cuenta FROM public.cuentas_bancarias
            WHERE id_cliente = %s AND tipo_metodo = 'transferencia' AND activa = TRUE
            LIMIT 1
            """,
            (id_cliente,),
        )
        existente = cur.fetchone()
        if existente:
            cur.execute(
                """
                UPDATE public.cuentas_bancarias
                SET iban = %s, titular_cuenta = %s, concepto_pago = %s,
                    es_principal = TRUE, fecha_actualizacion = NOW()
                WHERE id_cuenta = %s
                """,
                (iban, titular, concepto, existente[0]),
            )
        else:
            cur.execute(
                """
                INSERT INTO public.cuentas_bancarias
                  (id_cliente, tipo_metodo, iban, titular_cuenta, concepto_pago, es_principal)
                VALUES (%s, 'transferencia', %s, %s, %s, TRUE)
                """,
                (id_cliente, iban, titular, concepto),
            )
        return

    tarjetas = c.get("tarjetas") or extraer_tarjetas_autonomo(cliente)
    if not tarjetas:
        return

    numeros_activos: List[str] = []
    for tarjeta in tarjetas:
        numero = (tarjeta.get("numCuenta") or "").strip()
        cvv = (tarjeta.get("cvv") or "").strip()
        fecha_cad = (tarjeta.get("fechaCad") or "").strip()
        if not numero or not cvv or not fecha_cad:
            continue
        es_principal = bool(tarjeta.get("esPrincipal"))
        _upsert_tarjeta_autonomo(cur, id_cliente, numero, cvv, fecha_cad, es_principal)
        numeros_activos.append(numero)

    if not numeros_activos:
        return

    cur.execute(
        """
        UPDATE public.cuentas_bancarias
        SET activa = FALSE, fecha_actualizacion = NOW()
        WHERE id_cliente = %s AND tipo_metodo = 'tarjeta' AND activa = TRUE
          AND numero_cuenta <> ALL(%s)
        """,
        (id_cliente, numeros_activos),
    )

    principal = None
    for tarjeta in tarjetas:
        if tarjeta.get("esPrincipal"):
            principal = (tarjeta.get("numCuenta") or "").strip()
            break
    if not principal:
        principal = numeros_activos[0]
    cur.execute(
        """
        UPDATE public.cuentas_bancarias
        SET es_principal = (numero_cuenta = %s), fecha_actualizacion = NOW()
        WHERE id_cliente = %s AND tipo_metodo = 'tarjeta' AND activa = TRUE
        """,
        (principal, id_cliente),
    )


def guardar_cliente_cuenta(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Guarda cliente y cuentas bancarias al publicar tienda/cuenta/actualizada."""
    if not isinstance(payload, dict):
        payload = {}
    conn = pg8000.connect(
        user=PGUSER,
        password=PGPASSWORD,
        host=PGHOST,
        port=PGPORT,
        database=PGDATABASE,
    )
    conn.autocommit = False
    cur = conn.cursor()
    try:
        id_cliente = get_or_create_cliente(cur, payload)
        guardar_cuenta_bancaria(cur, id_cliente, payload)
        conn.commit()
        return {"ok": True, "idCliente": id_cliente}
    except Exception as ex:
        conn.rollback()
        return {"ok": False, "error": str(ex)}
    finally:
        cur.close()
        conn.close()


def publicar_cuenta_guardada(
    client: mqtt_client.Client, id_cliente: int, payload: Dict[str, Any]
) -> None:
    cliente = normalizar_cliente_web(payload)
    client.publish(
        "tienda/cuenta/guardada",
        json.dumps(
            {
                "ok": True,
                "idCliente": id_cliente,
                "tipoCliente": cliente.get("tipo"),
                "nombre": cliente.get("nombre"),
            },
            ensure_ascii=False,
        ),
        qos=1,
    )


# --- Envios y empresa de reparto --------------------------------------------


def listar_empresas_reparto(cur) -> List[Dict[str, Any]]:
    cur.execute(
        """
        SELECT id_empresa_reparto, nombre
        FROM public.empresas_reparto
        ORDER BY nombre
        """
    )
    return [{"id": row[0], "nombre": row[1]} for row in cur.fetchall()]


def resolver_empresa_reparto(cur, id_solicitado: Any) -> Optional[Dict[str, Any]]:
    if id_solicitado is not None:
        try:
            eid = int(id_solicitado)
        except (TypeError, ValueError):
            eid = None
        if eid is not None:
            cur.execute(
                """
                SELECT id_empresa_reparto, nombre FROM public.empresas_reparto
                WHERE id_empresa_reparto = %s LIMIT 1
                """,
                (eid,),
            )
            row = cur.fetchone()
            if row:
                return {"id_empresa_reparto": row[0], "nombre": row[1]}
    return obtener_empresa_reparto_por_defecto(cur)


def obtener_empresa_reparto_por_defecto(cur) -> Optional[Dict[str, Any]]:
    if EMPRESA_REPARTO_ID:
        try:
            eid = int(EMPRESA_REPARTO_ID)
        except ValueError:
            eid = None
        if eid is not None:
            cur.execute(
                """
                SELECT id_empresa_reparto, nombre FROM public.empresas_reparto
                WHERE id_empresa_reparto = %s LIMIT 1
                """,
                (eid,),
            )
            row = cur.fetchone()
            if row:
                return {"id_empresa_reparto": row[0], "nombre": row[1]}

    cur.execute(
        """
        SELECT id_empresa_reparto, nombre FROM public.empresas_reparto
        ORDER BY id_empresa_reparto LIMIT 1
        """
    )
    row = cur.fetchone()
    if row:
        return {"id_empresa_reparto": row[0], "nombre": row[1]}
    return None


def crear_envio_inicial(
    cur, id_pedido: int, id_empresa_reparto: Any = None
) -> Dict[str, Any]:
    empresa = resolver_empresa_reparto(cur, id_empresa_reparto)
    id_empresa = empresa["id_empresa_reparto"] if empresa else None
    cur.execute(
        """
        INSERT INTO public.envios (id_pedido, id_empresa_reparto, estado_envio)
        VALUES (%s, %s, 'pendiente')
        RETURNING id_envio
        """,
        (id_pedido, id_empresa),
    )
    id_envio = cur.fetchone()[0]
    return {
        "idEnvio": id_envio,
        "idEmpresaReparto": id_empresa,
        "nombreEmpresaReparto": empresa["nombre"] if empresa else None,
    }


# --- Procesar un pedido completo (transaccion) -------------------------------


def guardar_pedido(payload: Dict[str, Any]) -> Dict[str, Any]:
    conn = pg8000.connect(
        user=PGUSER,
        password=PGPASSWORD,
        host=PGHOST,
        port=PGPORT,
        database=PGDATABASE,
    )
    conn.autocommit = False
    cur = conn.cursor()
    try:
        cliente_raw = payload.get("cliente") or {}
        if not isinstance(cliente_raw, dict):
            cliente_raw = {}
        productos = payload.get("productos") or []
        if not isinstance(productos, list):
            productos = []
        total = float(payload.get("total") or 0)
        cajas = contar_cajas_grandes(productos)
        tipo = tipo_pedido_desde_carrito(productos)
        combinacion = obtener_numero_combinacion(productos, tipo)
        nota = (cliente_raw.get("nota") or payload.get("nota") or "").strip()
        observaciones = nota if nota else "Pedido recibido por MQTT"

        # 1) Cliente (autonomo/empresa desde Mi cuenta)
        id_cliente = get_or_create_cliente(cur, cliente_raw)
        try:
            guardar_cuenta_bancaria(cur, id_cliente, cliente_raw)
        except Exception as ex:
            print(f"Aviso: cuenta bancaria no guardada (el pedido continua): {ex}")

        # 2) Lineas en unidades de stock (sabores / cantidades)
        lineas = extraer_lineas_pedido(productos)
        faltantes = validar_stock_disponible(cur, lineas)
        if faltantes:
            conn.rollback()
            return {"ok": False, "motivo": "stock", "faltantes": faltantes, "combinacion": combinacion}

        # 3) Cabecera del pedido
        cur.execute(
            """
            INSERT INTO public.pedidos
              (id_cliente, tipo_pedido, cantidad_cajas_grandes, estado_pedido, precio_total, observaciones)
            VALUES
              (%s, %s, %s, 'pendiente', %s, %s)
            RETURNING id_pedido
            """,
            (id_cliente, tipo, cajas, total, observaciones),
        )
        id_pedido = cur.fetchone()[0]

        id_empresa_reparto = payload.get("idEmpresaReparto")
        if id_empresa_reparto is None and isinstance(cliente_raw, dict):
            id_empresa_reparto = cliente_raw.get("idEmpresaReparto")

        # 4) Envio inicial y empresa de reparto (tabla envios)
        envio = crear_envio_inicial(cur, id_pedido, id_empresa_reparto)

        # 5) Bajar stock antes de insertar lineas (misma transaccion)
        descontar_stock(cur, lineas)

        # 6) Detalle por sabor (tabla lineas_pedido)
        for linea in lineas:
            id_sabor = get_or_create_sabor(cur, linea["nombre"])
            cur.execute(
                """
                INSERT INTO public.lineas_pedido (id_pedido, id_sabor, cantidad_paquetes)
                VALUES (%s, %s, %s)
                """,
                (id_pedido, id_sabor, linea["cantidad"]),
            )

        if combinacion:
            cur.execute(
                """
                INSERT INTO public.pedidos_combinacion
                  (id_pedido, numero_combi, tamano, sabores_json)
                VALUES (%s, %s, %s, %s)
                ON CONFLICT (id_pedido) DO UPDATE
                SET numero_combi = EXCLUDED.numero_combi,
                    tamano = EXCLUDED.tamano,
                    sabores_json = EXCLUDED.sabores_json
                """,
                (
                    id_pedido,
                    combinacion["numero"],
                    combinacion["tamano"],
                    json.dumps(combinacion["sabores"], ensure_ascii=False),
                ),
            )

        cur.execute(
            "SELECT fecha_pedido FROM public.pedidos WHERE id_pedido = %s",
            (id_pedido,),
        )
        fecha_row = cur.fetchone()
        fecha_pedido = fecha_row[0] if fecha_row else datetime.now()

        conn.commit()
        return {
            "ok": True,
            "idPedido": id_pedido,
            "idCliente": id_cliente,
            "fechaPedido": fecha_pedido.isoformat() if hasattr(fecha_pedido, "isoformat") else str(fecha_pedido),
            "envio": envio,
            "lineas": lineas,
            "combinacion": combinacion,
        }
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()
        conn.close()


def parse_mqtt_url(url: str) -> Tuple[str, int, str, bool, bool]:
    u = urlparse(url)
    host = u.hostname or ""
    if not host:
        raise ValueError("URL MQTT sin host")
    scheme = (u.scheme or "mqtt").lower()
    port = u.port
    if port is None:
        if scheme in ("wss", "https"):
            port = 443
        elif scheme in ("mqtts", "ssl"):
            port = 8883
        elif scheme in ("ws", "http"):
            port = 80
        else:
            port = 1883
    path = u.path or "/mqtt"
    if not path.startswith("/"):
        path = "/" + path
    use_ws = scheme in ("ws", "wss", "http", "https")
    use_tls = scheme in ("mqtts", "wss", "https", "ssl")
    return host, port, path, use_ws, use_tls


def publicar_empresas_reparto(client: mqtt_client.Client) -> None:
    conn = pg8000.connect(
        user=PGUSER,
        password=PGPASSWORD,
        host=PGHOST,
        port=PGPORT,
        database=PGDATABASE,
    )
    try:
        cur = conn.cursor()
        empresas = listar_empresas_reparto(cur)
        cur.close()
        client.publish(
            MQTT_TOPIC_EMPRESAS_LISTA,
            json.dumps({"empresas": empresas}, ensure_ascii=False),
            qos=1,
            retain=True,
        )
        print(f"Publicadas {len(empresas)} empresas de reparto en {MQTT_TOPIC_EMPRESAS_LISTA}")
    finally:
        conn.close()


def on_connect(client: mqtt_client.Client, userdata: Any, flags: Any, reason_code: Any, properties: Any = None) -> None:
    if getattr(reason_code, "is_failure", False):
        print(f"MQTT error conexion: {reason_code}")
        return
    print(f"MQTT OK. Suscrito a {MQTT_TOPIC}, {MQTT_TOPIC_CUENTA}, {MQTT_TOPIC_EMPRESAS_SOLICITAR}")
    client.subscribe(MQTT_TOPIC, qos=1)
    client.subscribe(MQTT_TOPIC_CUENTA, qos=1)
    client.subscribe(MQTT_TOPIC_EMPRESAS_SOLICITAR, qos=1)
    publicar_empresas_reparto(client)


def on_message(client: mqtt_client.Client, userdata: Any, msg: mqtt_client.MQTTMessage) -> None:
    raw = msg.payload.decode("utf-8", errors="replace")
    topic = msg.topic
    try:
        payload = json.loads(raw)
        if topic == MQTT_TOPIC_CUENTA:
            resultado = guardar_cliente_cuenta(payload)
            if resultado.get("ok"):
                idc = resultado.get("idCliente")
                print(f"Cuenta cliente {idc} guardada en BD")
                publicar_cuenta_guardada(client, idc, payload)
            else:
                print("Error guardando cuenta:", resultado.get("error"))
            return

        if topic == MQTT_TOPIC_EMPRESAS_SOLICITAR:
            publicar_empresas_reparto(client)
            return

        if topic != MQTT_TOPIC:
            return

        resultado = guardar_pedido(payload)
        if not resultado.get("ok"):
            faltantes = resultado.get("faltantes") or []
            client.publish(
                "tienda/stock/alerta",
                json.dumps(
                    {
                        "estado": "rechazado_sin_stock",
                        "faltantes": faltantes,
                        "mensaje": "No hay stock suficiente para uno o varios sabores. Proveedores en camino.",
                        "numeroCombi": None,
                    },
                    ensure_ascii=False,
                ),
                qos=1,
            )
            # Borra el ultimo numero retenido en status para que RoboDK no ejecute un pedido viejo
            client.publish(
                STATION_STATUS_TOPIC,
                json.dumps({"estado": "rechazado_sin_stock"}, ensure_ascii=False),
                qos=1,
                retain=True,
            )
            print("Pedido rechazado por falta de stock:")
            for f in faltantes:
                print(
                    f"  - {f.get('sabor')}: piden {f.get('pedido')} paquetes, hay {f.get('stock')} "
                    f"(id_sabor {f.get('idSabor')})"
                )
            return

        cliente_raw = payload.get("cliente") or {}
        if not isinstance(cliente_raw, dict):
            cliente_raw = {}
        cliente = normalizar_cliente_web(cliente_raw)
        productos = payload.get("productos") or []
        if not isinstance(productos, list):
            productos = []
        resumen = extraer_resumen_pedido(productos)
        combinacion = resultado.get("combinacion")
        tamano = combinacion["tamano"] if combinacion else resumen["numeroCajas"]
        idp = resultado["idPedido"]
        id_cliente = resultado.get("idCliente")
        e = resultado["envio"]
        tipo_pedido = tipo_pedido_desde_carrito(productos)
        fecha_pedido = resultado.get("fechaPedido") or datetime.now().isoformat()

        # tienda: confirmacion con datos de autonomo/empresa
        topic_tienda = "tienda/pedido/confirmado"
        client.publish(
            topic_tienda,
            json.dumps(
                {
                    "confirmado": True,
                    "idPedido": idp,
                    "idCliente": id_cliente,
                    "fechaHora": fecha_pedido,
                    "tipoCliente": cliente.get("tipo"),
                    "formaJuridica": cliente.get("formaJuridica"),
                    "tipoPedido": tipo_pedido,
                    "nombre": cliente.get("nombre"),
                    "cif": cliente.get("cif"),
                    "email": cliente.get("email"),
                    "telefono": cliente.get("telefono"),
                    "direccion": cliente.get("direccion"),
                    "direccionEnvio": cliente.get("direccionEnvio"),
                    "codigoPostal": cliente.get("codigoPostal"),
                    "direccionFiscal": cliente.get("direccionFiscal"),
                    "codigoPostalFiscal": cliente.get("codigoPostalFiscal"),
                    "empresa": cliente.get("empresa"),
                    "departamento": cliente.get("departamento"),
                    "idEmpresaReparto": e.get("idEmpresaReparto"),
                    "empresaReparto": e.get("nombreEmpresaReparto"),
                    "numeroCajas": resumen["numeroCajas"],
                    "sabores": resumen["sabores"],
                    "detalleIndustrial": resumen.get("detalleIndustrial"),
                    "detallePersonalizado": resumen.get("detallePersonalizado"),
                    "precioTotal": float(payload.get("total") or 0),
                    "numeroCombi": combinacion["numero"] if combinacion else None,
                    "rutaCombi": combinacion["ruta"] if combinacion else None,
                },
                ensure_ascii=False,
            ),
            qos=1,
        )
        print(f"MQTT -> {topic_tienda} (pedido {idp})")
        # logistica: reparto y envio
        topic_logistica = f"{LOGISTICA_TOPIC_PREFIX}/pedido/{idp}"
        client.publish(
            topic_logistica,
            json.dumps(
                {
                    "idPedido": idp,
                    "tipoCliente": cliente.get("tipo"),
                    "nombreCliente": cliente.get("nombre"),
                    "cif": cliente.get("cif"),
                    "empresaReparto": e["nombreEmpresaReparto"],
                    "direccionEnvio": cliente.get("direccion"),
                    "tamano": tamano,
                    "tipoPedido": tipo_pedido,
                    "numeroCombi": combinacion["numero"] if combinacion else None,
                },
                ensure_ascii=False,
            ),
            qos=1,
        )
        print(f"MQTT -> {topic_logistica}")
        # fabrica: aviso de produccion (sin duplicar numero_combi)
        client.publish(
            FABRICA_TOPIC,
            json.dumps(
                {
                    "evento": "pedido_guardado",
                    "idPedido": idp,
                    "numeroCajas": resumen["numeroCajas"],
                    "tipoPedido": tipo_pedido,
                },
                ensure_ascii=False,
            ),
            qos=1,
        )
        print(f"MQTT -> {FABRICA_TOPIC}")
        # numero_combi + estacion: mismo numeroCombi en ambos topics
        if combinacion:
            numero_combi = combinacion["numero"]
            client.publish(
                NUMERO_COMBI_TOPIC,
                json.dumps(
                    {
                        "numeroCombi": numero_combi,
                        "ruta": combinacion["ruta"],
                        "sabores": combinacion["sabores"],
                    },
                    ensure_ascii=False,
                ),
                qos=1,
                retain=True,
            )
            client.publish(STATION_STATUS_TOPIC, str(numero_combi), qos=1, retain=True)
            print(
                f"MQTT -> {NUMERO_COMBI_TOPIC} y {STATION_STATUS_TOPIC} "
                f"(numeroCombi={numero_combi})"
            )
        else:
            print("Sin combinacion industrial (1-4 cajas): no se publica numero_combi/status")
        print(f"Pedido {idp} guardado (entrada {topic})")
    except Exception as ex:
        print("Error procesando MQTT:", ex)
        print("Payload:", raw)


def main() -> None:
    comprobar_variables_mqtt()
    conn = pg8000.connect(
        user=PGUSER,
        password=PGPASSWORD,
        host=PGHOST,
        port=PGPORT,
        database=PGDATABASE,
    )
    asegurar_tablas_combinaciones(conn)
    asegurar_columnas_cliente(conn)
    asegurar_esquema_cuentas_bancarias(conn)
    conn.close()
    print("DB conectada")

    host, port, path, use_ws, use_tls = parse_mqtt_url(MQTT_URL)
    cid = "db_bridge_py_" + "".join(random.choices(string.ascii_lowercase + string.digits, k=8))
    cli = mqtt_client.Client(
        callback_api_version=CallbackAPIVersion.VERSION2,
        client_id=cid,
        transport="websockets" if use_ws else "tcp",
    )
    if use_ws:
        cli.ws_set_options(path=path)
    if use_tls:
        cli.tls_set(ca_certs=certifi.where(), cert_reqs=ssl.CERT_REQUIRED)

    cli.username_pw_set(MQTT_USERNAME, MQTT_PASSWORD)
    cli.on_connect = on_connect
    cli.on_message = on_message
    print(f"Conectando MQTT a {host}:{port} ...")
    cli.connect(host, port, keepalive=60)
    cli.loop_forever()


if __name__ == "__main__":
    main()
