-- Campos de dirección para Mi cuenta (autónomo y empresa).
-- Ejecutar en pgAdmin sobre PLanta_PR2.

ALTER TABLE public.clientes
  ADD COLUMN IF NOT EXISTS direccion_envio TEXT,
  ADD COLUMN IF NOT EXISTS codigo_postal VARCHAR(10),
  ADD COLUMN IF NOT EXISTS direccion_fiscal TEXT,
  ADD COLUMN IF NOT EXISTS codigo_postal_fiscal VARCHAR(10),
  ADD COLUMN IF NOT EXISTS forma_juridica VARCHAR(20);

COMMENT ON COLUMN public.clientes.direccion_envio IS 'Dirección de envío de pedidos';
COMMENT ON COLUMN public.clientes.direccion_fiscal IS 'Dirección fiscal / facturación';
COMMENT ON COLUMN public.clientes.forma_juridica IS 'autonomo, SL o SA';
