-- Cuentas bancarias por cliente (alineado con Mi cuenta en la web).
--
-- Reglas:
--   - Cada fila pertenece a UN solo cliente (id_cliente).
--   - Cliente tipo empresa: exactamente UNA cuenta activa (transferencia / IBAN).
--   - Cliente tipo autonomo: una o varias cuentas (tarjeta); la web envía una por defecto.
--   - El tipo de metodo debe coincidir con tipo_cliente en public.clientes.
--
-- Ejecutar en pgAdmin (Query Tool) sobre PLanta_PR2:
--   psql -h localhost -U postgres -d PLanta_PR2 -v ON_ERROR_STOP=1 -f sql/cuentas_bancarias.sql

BEGIN;

CREATE TABLE IF NOT EXISTS public.cuentas_bancarias (
  id_cuenta SERIAL PRIMARY KEY,
  id_cliente INTEGER NOT NULL
    REFERENCES public.clientes (id_cliente) ON DELETE CASCADE,

  tipo_metodo VARCHAR(20) NOT NULL
    CHECK (tipo_metodo IN ('tarjeta', 'transferencia')),

  -- Autonomo (tarjeta) — mismos campos que la web
  numero_cuenta VARCHAR(19),
  cvv VARCHAR(4),
  fecha_caducidad VARCHAR(7),

  -- Empresa (transferencia bancaria)
  iban VARCHAR(34),
  titular_cuenta VARCHAR(120),
  concepto_pago VARCHAR(200),

  es_principal BOOLEAN NOT NULL DEFAULT TRUE,
  activa BOOLEAN NOT NULL DEFAULT TRUE,
  fecha_registro TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  fecha_actualizacion TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  CONSTRAINT ck_cuenta_tarjeta_completa CHECK (
    tipo_metodo <> 'tarjeta'
    OR (
      numero_cuenta IS NOT NULL
      AND LENGTH(TRIM(numero_cuenta)) >= 8
      AND cvv IS NOT NULL
      AND LENGTH(TRIM(cvv)) BETWEEN 3 AND 4
      AND fecha_caducidad IS NOT NULL
      AND LENGTH(TRIM(fecha_caducidad)) > 0
    )
  ),

  CONSTRAINT ck_cuenta_transferencia_completa CHECK (
    tipo_metodo <> 'transferencia'
    OR (
      iban IS NOT NULL
      AND LENGTH(TRIM(iban)) >= 15
      AND titular_cuenta IS NOT NULL
      AND LENGTH(TRIM(titular_cuenta)) > 0
      AND concepto_pago IS NOT NULL
      AND LENGTH(TRIM(concepto_pago)) > 0
    )
  )
);

COMMENT ON TABLE public.cuentas_bancarias IS
  'Datos de pago de Mi cuenta. Una cuenta pertenece a un solo cliente.';
COMMENT ON COLUMN public.cuentas_bancarias.tipo_metodo IS
  'tarjeta = autonomo; transferencia = empresa (IBAN).';
COMMENT ON COLUMN public.cuentas_bancarias.es_principal IS
  'Cuenta por defecto si el autonomo tiene varias tarjetas.';

CREATE INDEX IF NOT EXISTS idx_cuentas_bancarias_cliente
  ON public.cuentas_bancarias (id_cliente);

-- Evita duplicar la misma tarjeta para el mismo cliente
CREATE UNIQUE INDEX IF NOT EXISTS uq_cuenta_tarjeta_por_cliente
  ON public.cuentas_bancarias (id_cliente, numero_cuenta)
  WHERE tipo_metodo = 'tarjeta' AND activa = TRUE;

-- IBAN unico en el sistema (una cuenta = una identidad de pago)
CREATE UNIQUE INDEX IF NOT EXISTS uq_cuenta_iban_activo
  ON public.cuentas_bancarias (iban)
  WHERE tipo_metodo = 'transferencia' AND activa = TRUE AND iban IS NOT NULL;

-- Empresa: como mucho UNA cuenta activa por cliente
CREATE UNIQUE INDEX IF NOT EXISTS uq_una_cuenta_activa_empresa
  ON public.cuentas_bancarias (id_cliente)
  WHERE tipo_metodo = 'transferencia' AND activa = TRUE;

-- --- Triggers: coherencia con tipo_cliente y limite empresa ----------------

CREATE OR REPLACE FUNCTION public.trg_cuentas_bancarias_validar()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  v_tipo_cliente VARCHAR(20);
  v_cuentas_empresa INT;
BEGIN
  SELECT c.tipo_cliente INTO v_tipo_cliente
  FROM public.clientes c
  WHERE c.id_cliente = NEW.id_cliente;

  IF v_tipo_cliente IS NULL THEN
    RAISE EXCEPTION 'id_cliente % no existe en clientes', NEW.id_cliente;
  END IF;

  IF v_tipo_cliente = 'empresa' AND NEW.tipo_metodo <> 'transferencia' THEN
    RAISE EXCEPTION 'Cliente empresa: solo se permite tipo_metodo transferencia';
  END IF;

  IF v_tipo_cliente = 'autonomo' AND NEW.tipo_metodo <> 'tarjeta' THEN
    RAISE EXCEPTION 'Cliente autonomo: solo se permite tipo_metodo tarjeta';
  END IF;

  IF v_tipo_cliente = 'empresa' AND NEW.tipo_metodo = 'transferencia' AND NEW.activa THEN
    SELECT COUNT(*) INTO v_cuentas_empresa
    FROM public.cuentas_bancarias cb
    WHERE cb.id_cliente = NEW.id_cliente
      AND cb.tipo_metodo = 'transferencia'
      AND cb.activa = TRUE
      AND cb.id_cuenta IS DISTINCT FROM NEW.id_cuenta;

    IF v_cuentas_empresa >= 1 THEN
      RAISE EXCEPTION 'Cliente empresa: solo puede tener una cuenta bancaria activa';
    END IF;
  END IF;

  NEW.fecha_actualizacion := NOW();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS cuentas_bancarias_validar ON public.cuentas_bancarias;
CREATE TRIGGER cuentas_bancarias_validar
BEFORE INSERT OR UPDATE ON public.cuentas_bancarias
FOR EACH ROW
EXECUTE PROCEDURE public.trg_cuentas_bancarias_validar();

-- Vista util: cliente + su(s) cuenta(s)
CREATE OR REPLACE VIEW public.v_clientes_cuentas_bancarias AS
SELECT
  c.id_cliente,
  c.tipo_cliente,
  c.cif,
  c.nombre,
  c.nombre_empresa,
  cb.id_cuenta,
  cb.tipo_metodo,
  cb.numero_cuenta,
  cb.fecha_caducidad,
  cb.iban,
  cb.titular_cuenta,
  cb.concepto_pago,
  cb.es_principal,
  cb.activa,
  cb.fecha_registro
FROM public.clientes c
LEFT JOIN public.cuentas_bancarias cb
  ON cb.id_cliente = c.id_cliente AND cb.activa = TRUE;

COMMIT;
