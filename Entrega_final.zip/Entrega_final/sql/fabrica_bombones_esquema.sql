-- Esquema fábrica de bombones (PostgreSQL).
-- Incluye el modelo base + extensiones alineadas con el esquema en papel (ingredientes, cajas,
-- palés, fechas/estado/importe del pedido, NIF cliente, plazo proveedor, tipo/estado del robot)
-- y la regla de negocio: 4 tipos de pallet — 3 para INDUSTRIAL y 1 para PERSONALIZADO.
--
-- Ejecución (ejemplo):
--   psql -h localhost -U postgres -d PLanta_PR2 -v ON_ERROR_STOP=1 -f sql/fabrica_bombones_esquema.sql
--
-- Nota: si las tablas ya existen, este script fallará en el primer CREATE; usa una BD vacía o
-- elimina objetos manualmente antes de re-ejecutar.

BEGIN;

CREATE TABLE tipo_empresa_cliente (
  id_tipo_empresa SERIAL PRIMARY KEY,
  codigo VARCHAR(50) NOT NULL UNIQUE,
  nombre VARCHAR(120) NOT NULL
);

CREATE TABLE departamento_empresa_cliente (
  id_departamento SERIAL PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL
);

CREATE TABLE cliente (
  id_cliente SERIAL PRIMARY KEY,
  nif VARCHAR(9) UNIQUE,
  nombre VARCHAR(120) NOT NULL,
  nombre_empresa VARCHAR(200),
  id_tipo_empresa INT NOT NULL REFERENCES tipo_empresa_cliente(id_tipo_empresa),
  es_autonomo BOOLEAN NOT NULL DEFAULT FALSE,
  id_departamento_empresa INT REFERENCES departamento_empresa_cliente(id_departamento),
  email VARCHAR(200),
  telefono VARCHAR(40),
  direccion VARCHAR(200),
  fecha_registro DATE NOT NULL DEFAULT CURRENT_DATE,
  CONSTRAINT ck_cliente_departamento CHECK (
    (es_autonomo = TRUE AND id_departamento_empresa IS NULL)
    OR (es_autonomo = FALSE)
  )
);

CREATE TABLE proveedor (
  id_proveedor SERIAL PRIMARY KEY,
  nombre VARCHAR(200) NOT NULL,
  direccion VARCHAR(200),
  contacto VARCHAR(200),
  telefono VARCHAR(40),
  email VARCHAR(200),
  plazo_entrega_medio INT CHECK (plazo_entrega_medio IS NULL OR plazo_entrega_medio >= 0),
  notas TEXT
);

CREATE TABLE sabor (
  id_sabor SERIAL PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL UNIQUE,
  id_proveedor INT NOT NULL REFERENCES proveedor(id_proveedor),
  activo BOOLEAN NOT NULL DEFAULT TRUE,
  tiempo_produccion_estimado_horas INT CHECK (tiempo_produccion_estimado_horas IS NULL OR tiempo_produccion_estimado_horas > 0)
);

CREATE TABLE tipo_caja_grande (
  id_tipo_caja_grande SERIAL PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  capacidad_cajas_pequenas INT NOT NULL DEFAULT 48,
  id_proveedor INT NOT NULL REFERENCES proveedor(id_proveedor)
);

CREATE TABLE empresa_envio (
  id_empresa_envio SERIAL PRIMARY KEY,
  nombre VARCHAR(200) NOT NULL,
  telefono VARCHAR(40),
  web VARCHAR(300)
);

-- Catálogo cerrado de pallets: exactamente 3 filas INDUSTRIAL + 1 PERSONALIZADO (semilla más abajo).
CREATE TABLE tipo_pale (
  id_tipo_pale SERIAL PRIMARY KEY,
  codigo VARCHAR(50) NOT NULL UNIQUE,
  nombre VARCHAR(120) NOT NULL,
  tipo_pedido VARCHAR(20) NOT NULL CHECK (tipo_pedido IN ('PERSONALIZADO', 'INDUSTRIAL'))
);

CREATE TABLE pedido (
  id_pedido SERIAL PRIMARY KEY,
  id_cliente INT NOT NULL REFERENCES cliente(id_cliente),
  tipo_pedido VARCHAR(20) NOT NULL CHECK (tipo_pedido IN ('PERSONALIZADO', 'INDUSTRIAL')),
  id_tipo_pale INT NOT NULL REFERENCES tipo_pale(id_tipo_pale),
  direccion_envio TEXT NOT NULL,
  fecha_pedido TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  fecha_entrega_prevista DATE,
  fecha_entrega_real DATE,
  estado VARCHAR(20) NOT NULL DEFAULT 'pendiente' CHECK (
    estado IN ('pendiente', 'en producción', 'completado', 'enviado', 'entregado')
  ),
  importe_total NUMERIC(14, 2) NOT NULL DEFAULT 0 CHECK (importe_total >= 0),
  id_empresa_envio INT NOT NULL REFERENCES empresa_envio(id_empresa_envio),
  id_tipo_caja_grande INT REFERENCES tipo_caja_grande(id_tipo_caja_grande),
  observaciones TEXT,
  CONSTRAINT ck_pedido_caja_grande CHECK (
    (tipo_pedido = 'PERSONALIZADO' AND id_tipo_caja_grande IS NOT NULL)
    OR (tipo_pedido = 'INDUSTRIAL')
  )
);

CREATE OR REPLACE FUNCTION trg_validar_tipo_pale_pedido()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM tipo_pale tp
    WHERE tp.id_tipo_pale = NEW.id_tipo_pale
      AND tp.tipo_pedido = NEW.tipo_pedido
  ) THEN
    RAISE EXCEPTION
      'id_tipo_pale % no es válido para tipo_pedido %',
      NEW.id_tipo_pale,
      NEW.tipo_pedido;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER pedido_validar_tipo_pale
BEFORE INSERT OR UPDATE OF id_tipo_pale, tipo_pedido ON pedido
FOR EACH ROW
EXECUTE PROCEDURE trg_validar_tipo_pale_pedido();

CREATE TABLE linea_pedido_personalizado (
  id_linea SERIAL PRIMARY KEY,
  id_pedido INT NOT NULL REFERENCES pedido(id_pedido) ON DELETE CASCADE,
  id_sabor INT NOT NULL REFERENCES sabor(id_sabor),
  num_cajas_pequenas INT NOT NULL CHECK (num_cajas_pequenas > 0),
  cantidad_producida INT NOT NULL DEFAULT 0 CHECK (cantidad_producida >= 0),
  precio_unitario NUMERIC(14, 4) NOT NULL DEFAULT 0 CHECK (precio_unitario >= 0),
  UNIQUE (id_pedido, id_sabor)
);

CREATE TABLE linea_pedido_industrial (
  id_linea SERIAL PRIMARY KEY,
  id_pedido INT NOT NULL REFERENCES pedido(id_pedido) ON DELETE CASCADE,
  id_sabor INT NOT NULL REFERENCES sabor(id_sabor),
  num_cajas_grandes INT NOT NULL CHECK (num_cajas_grandes > 0),
  cantidad_producida INT NOT NULL DEFAULT 0 CHECK (cantidad_producida >= 0),
  precio_unitario NUMERIC(14, 4) NOT NULL DEFAULT 0 CHECK (precio_unitario >= 0)
);

CREATE TABLE departamento_interno (
  id_departamento_interno SERIAL PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL UNIQUE,
  descripcion TEXT
);

CREATE TABLE tipo_cinta_transportadora (
  id_tipo_cinta SERIAL PRIMARY KEY,
  codigo VARCHAR(50) NOT NULL UNIQUE,
  nombre VARCHAR(120) NOT NULL
);

CREATE TABLE cinta_transportadora (
  id_cinta SERIAL PRIMARY KEY,
  codigo_inventario VARCHAR(80) UNIQUE,
  id_tipo_cinta INT NOT NULL REFERENCES tipo_cinta_transportadora(id_tipo_cinta),
  id_departamento INT REFERENCES departamento_interno(id_departamento_interno),
  ubicacion VARCHAR(200),
  longitud_metros NUMERIC(10, 2),
  activa BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE tipo_sensor (
  id_tipo_sensor SERIAL PRIMARY KEY,
  codigo VARCHAR(50) NOT NULL UNIQUE,
  nombre VARCHAR(120) NOT NULL
);

CREATE TABLE sensor (
  id_sensor SERIAL PRIMARY KEY,
  codigo_inventario VARCHAR(80) UNIQUE,
  id_tipo_sensor INT NOT NULL REFERENCES tipo_sensor(id_tipo_sensor),
  id_cinta INT REFERENCES cinta_transportadora(id_cinta),
  ubicacion VARCHAR(200),
  modelo VARCHAR(120),
  activo BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE subsistema_seguridad (
  id_subsistema SERIAL PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  descripcion TEXT
);

CREATE TABLE componente_seguridad (
  id_componente SERIAL PRIMARY KEY,
  id_subsistema INT NOT NULL REFERENCES subsistema_seguridad(id_subsistema),
  tipo_componente VARCHAR(80) NOT NULL,
  codigo_inventario VARCHAR(80) UNIQUE,
  ubicacion VARCHAR(200),
  activo BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE robot (
  id_robot SERIAL PRIMARY KEY,
  codigo VARCHAR(50) NOT NULL UNIQUE,
  nombre VARCHAR(120) NOT NULL,
  id_departamento INT REFERENCES departamento_interno(id_departamento_interno),
  modelo VARCHAR(120),
  tipo_robot VARCHAR(15) NOT NULL CHECK (tipo_robot IN ('clasificador', 'selector', 'paletizador')),
  estado_operativo VARCHAR(15) NOT NULL DEFAULT 'activo' CHECK (estado_operativo IN ('activo', 'inactivo', 'mantenimiento')),
  activo BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE efector_final (
  id_efector SERIAL PRIMARY KEY,
  id_robot INT NOT NULL REFERENCES robot(id_robot) ON DELETE CASCADE,
  tipo_efector VARCHAR(80) NOT NULL,
  descripcion TEXT,
  CONSTRAINT uq_efector_un_robot UNIQUE (id_robot)
);

CREATE TABLE robot_sensor (
  id_robot INT NOT NULL REFERENCES robot(id_robot) ON DELETE CASCADE,
  id_sensor INT NOT NULL REFERENCES sensor(id_sensor) ON DELETE CASCADE,
  rol VARCHAR(80),
  PRIMARY KEY (id_robot, id_sensor)
);

-- Ingredientes (inventario y tipología del boceto).
CREATE TABLE ingrediente (
  id_ingrediente SERIAL PRIMARY KEY,
  codigo VARCHAR(5) NOT NULL UNIQUE,
  nombre VARCHAR(50) NOT NULL,
  unidad_medida VARCHAR(10) NOT NULL,
  precio_unitario NUMERIC(14, 4) NOT NULL CHECK (precio_unitario >= 0),
  tipo VARCHAR(20) NOT NULL CHECK (tipo IN ('materia prima', 'aditivo', 'envase', 'etiqueta')),
  perecedero BOOLEAN NOT NULL DEFAULT FALSE,
  tiempo_vida_util_dias INT,
  cantidad_actual NUMERIC(14, 4) NOT NULL DEFAULT 0 CHECK (cantidad_actual >= 0),
  stock_minimo NUMERIC(14, 4) NOT NULL DEFAULT 0 CHECK (stock_minimo >= 0),
  stock_maximo NUMERIC(14, 4) NOT NULL CHECK (stock_maximo > stock_minimo),
  fecha_ultima_actualizacion TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT ck_ingrediente_perecedero CHECK (
    (perecedero = TRUE AND tiempo_vida_util_dias IS NOT NULL AND tiempo_vida_util_dias > 0)
    OR (perecedero = FALSE AND tiempo_vida_util_dias IS NULL)
  )
);

CREATE TABLE receta_sabor_ingrediente (
  id_sabor INT NOT NULL REFERENCES sabor(id_sabor) ON DELETE CASCADE,
  id_ingrediente INT NOT NULL REFERENCES ingrediente(id_ingrediente) ON DELETE CASCADE,
  cantidad NUMERIC(14, 6) NOT NULL CHECK (cantidad > 0),
  PRIMARY KEY (id_sabor, id_ingrediente)
);

-- Caja unitaria de producto terminado (trazabilidad en planta).
CREATE TABLE caja (
  id_caja SERIAL PRIMARY KEY,
  identificador VARCHAR(10) NOT NULL UNIQUE,
  id_sabor INT NOT NULL REFERENCES sabor(id_sabor),
  peso NUMERIC(10, 3) NOT NULL CHECK (peso > 0),
  estado_control VARCHAR(30) NOT NULL CHECK (estado_control IN ('pendiente de pesaje', 'correcto', 'rechazado')),
  fecha_fabricacion DATE NOT NULL,
  fecha_caducidad DATE NOT NULL,
  proceso_fabricacion VARCHAR(10) NOT NULL,
  lote VARCHAR(10),
  id_pedido INT REFERENCES pedido(id_pedido)
);

-- Instancia física de pallet (catálogo de tipos en tipo_pale).
CREATE TABLE pale (
  id_pale SERIAL PRIMARY KEY,
  identificador VARCHAR(10) NOT NULL UNIQUE,
  id_tipo_pale INT NOT NULL REFERENCES tipo_pale(id_tipo_pale),
  estado VARCHAR(12) NOT NULL CHECK (estado IN ('vacío', 'en carga', 'completo', 'retirado')),
  id_pedido INT REFERENCES pedido(id_pedido)
);

ALTER TABLE caja
  ADD COLUMN id_pale INT REFERENCES pale(id_pale);

CREATE VIEW v_pedido_personalizado_totales AS
SELECT
  p.id_pedido,
  SUM(l.num_cajas_pequenas) AS total_cajas_pequenas
FROM pedido p
JOIN linea_pedido_personalizado l ON l.id_pedido = p.id_pedido
WHERE p.tipo_pedido = 'PERSONALIZADO'
GROUP BY p.id_pedido;

CREATE VIEW v_pedido_industrial_totales AS
SELECT
  p.id_pedido,
  SUM(l.num_cajas_grandes) AS total_cajas_grandes
FROM pedido p
JOIN linea_pedido_industrial l ON l.id_pedido = p.id_pedido
WHERE p.tipo_pedido = 'INDUSTRIAL'
GROUP BY p.id_pedido;

-- KPIs (consultas de cuadro de mando; requieren datos reales en pedido/fechas/stock).
CREATE VIEW v_kpi_pedidos_por_estado AS
SELECT
  estado,
  tipo_pedido,
  COUNT(*) AS num_pedidos,
  COALESCE(SUM(importe_total), 0) AS importe_total
FROM pedido
GROUP BY estado, tipo_pedido;

CREATE VIEW v_kpi_otd_entrega AS
SELECT
  id_pedido,
  tipo_pedido,
  (fecha_pedido AT TIME ZONE 'UTC')::date AS fecha_pedido_dia,
  fecha_entrega_prevista,
  fecha_entrega_real,
  (fecha_entrega_real - fecha_entrega_prevista) AS dias_desviacion,
  (fecha_entrega_real <= fecha_entrega_prevista) AS entregado_a_tiempo
FROM pedido
WHERE fecha_entrega_prevista IS NOT NULL
  AND fecha_entrega_real IS NOT NULL;

CREATE VIEW v_kpi_volumen_por_sabor AS
SELECT
  s.id_sabor,
  s.nombre,
  COALESCE(pp.total, 0)::bigint AS cajas_pequenas_pedidas,
  COALESCE(pi.total, 0)::bigint AS cajas_grandes_pedidas
FROM sabor s
LEFT JOIN (
  SELECT id_sabor, SUM(num_cajas_pequenas) AS total
  FROM linea_pedido_personalizado
  GROUP BY id_sabor
) pp ON pp.id_sabor = s.id_sabor
LEFT JOIN (
  SELECT id_sabor, SUM(num_cajas_grandes) AS total
  FROM linea_pedido_industrial
  GROUP BY id_sabor
) pi ON pi.id_sabor = s.id_sabor;

CREATE VIEW v_kpi_ingredientes_bajo_minimo AS
SELECT
  id_ingrediente,
  codigo,
  nombre,
  tipo,
  cantidad_actual,
  stock_minimo,
  (stock_minimo - cantidad_actual) AS deficit
FROM ingrediente
WHERE cantidad_actual < stock_minimo;

CREATE VIEW v_kpi_robots_por_estado AS
SELECT estado_operativo, COUNT(*) AS cantidad
FROM robot
WHERE activo = TRUE
GROUP BY estado_operativo;

CREATE VIEW v_kpi_pales_por_tipo_estado AS
SELECT
  tp.codigo,
  tp.nombre AS tipo_pale_nombre,
  tp.tipo_pedido,
  pl.estado AS estado_pale,
  COUNT(*) AS cantidad
FROM pale pl
JOIN tipo_pale tp ON tp.id_tipo_pale = pl.id_tipo_pale
GROUP BY tp.codigo, tp.nombre, tp.tipo_pedido, pl.estado;

-- Semilla: 3 pallets industriales + 1 personalizado (única combinación permitida por negocio).
INSERT INTO tipo_pale (codigo, nombre, tipo_pedido) VALUES
  ('PAL-IND-EUR-1', 'Pallet industrial EUR estándar 1', 'INDUSTRIAL'),
  ('PAL-IND-EUR-2', 'Pallet industrial EUR estándar 2', 'INDUSTRIAL'),
  ('PAL-IND-BLOQUE', 'Pallet industrial bloque / display', 'INDUSTRIAL'),
  ('PAL-PERS-REGALO', 'Pallet personalizado (regalo / mix pequeño)', 'PERSONALIZADO');

COMMIT;
