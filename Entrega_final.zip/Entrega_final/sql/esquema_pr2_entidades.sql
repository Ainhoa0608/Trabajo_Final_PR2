-- Esquema PR2: cliente, pedido, caja, bombón, robot, proveedor, restock, palet, detalle_pedido.
-- PostgreSQL. Ejecutar en una base vacía o tras eliminar objetos con el mismo nombre.
--
--   psql -h localhost -U postgres -d TU_BD -v ON_ERROR_STOP=1 -f sql/esquema_pr2_entidades.sql
--
-- Reglas automáticas:
--   - INSERT/UPDATE/DELETE en detalle_pedido ajusta bombon.stock (no permite stock negativo).
--   - INSERT en restock suma cantidad a bombon.stock.

BEGIN;

CREATE TABLE cliente (
  id_cliente SERIAL PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  correo VARCHAR(200),
  telefono VARCHAR(40),
  CONSTRAINT ck_cliente_contacto CHECK (
    nombre IS NOT NULL AND (LENGTH(TRIM(nombre)) > 0)
  )
);

CREATE UNIQUE INDEX uq_cliente_correo_no_nulo ON cliente (correo) WHERE correo IS NOT NULL;

CREATE TABLE proveedor (
  id_proveedor SERIAL PRIMARY KEY,
  nombre VARCHAR(200) NOT NULL,
  telefono VARCHAR(40)
);

CREATE TABLE bombon (
  id_bombon SERIAL PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  sabor VARCHAR(80) NOT NULL,
  peso NUMERIC(8, 3) NOT NULL CHECK (peso > 0),
  stock INT NOT NULL DEFAULT 0 CHECK (stock >= 0)
);

CREATE TABLE robot (
  id_robot SERIAL PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  estado VARCHAR(30) NOT NULL DEFAULT 'inactivo' CHECK (
    estado IN ('activo', 'inactivo', 'mantenimiento', 'averiado')
  )
);

CREATE TABLE palet (
  id_palet SERIAL PRIMARY KEY,
  capacidad INT NOT NULL CHECK (capacidad > 0),
  estado VARCHAR(30) NOT NULL DEFAULT 'vacío' CHECK (
    estado IN ('vacío', 'en carga', 'completo', 'retirado')
  )
);

CREATE TABLE pedido (
  id_pedido SERIAL PRIMARY KEY,
  fecha TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  tipo VARCHAR(20) NOT NULL CHECK (tipo IN ('personalizado', 'industrial')),
  estado VARCHAR(30) NOT NULL DEFAULT 'pendiente' CHECK (
    estado IN ('pendiente', 'en producción', 'completado', 'enviado', 'entregado', 'cancelado')
  ),
  id_cliente INT NOT NULL REFERENCES cliente (id_cliente) ON DELETE RESTRICT
);

CREATE TABLE detalle_pedido (
  id_pedido INT NOT NULL REFERENCES pedido (id_pedido) ON DELETE CASCADE,
  id_bombon INT NOT NULL REFERENCES bombon (id_bombon) ON DELETE RESTRICT,
  cantidad INT NOT NULL CHECK (cantidad > 0),
  PRIMARY KEY (id_pedido, id_bombon)
);

CREATE TABLE caja (
  id_caja SERIAL PRIMARY KEY,
  capacidad INT NOT NULL CHECK (capacidad > 0),
  qr VARCHAR(200) NOT NULL UNIQUE,
  id_pedido INT NOT NULL REFERENCES pedido (id_pedido) ON DELETE CASCADE
);

CREATE TABLE restock (
  id_restock SERIAL PRIMARY KEY,
  fecha TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  cantidad INT NOT NULL CHECK (cantidad > 0),
  id_bombon INT NOT NULL REFERENCES bombon (id_bombon) ON DELETE RESTRICT,
  id_proveedor INT NOT NULL REFERENCES proveedor (id_proveedor) ON DELETE RESTRICT
);

CREATE INDEX idx_pedido_cliente ON pedido (id_cliente);
CREATE INDEX idx_detalle_bombon ON detalle_pedido (id_bombon);
CREATE INDEX idx_caja_pedido ON caja (id_pedido);
CREATE INDEX idx_restock_bombon ON restock (id_bombon);
CREATE INDEX idx_restock_proveedor ON restock (id_proveedor);

-- --- Stock: restock suma -----------------------------------------------------

CREATE OR REPLACE FUNCTION trg_restock_suma_stock()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE bombon
  SET stock = stock + NEW.cantidad
  WHERE id_bombon = NEW.id_bombon;
  RETURN NEW;
END;
$$;

CREATE TRIGGER restock_ai_suma_stock
AFTER INSERT ON restock
FOR EACH ROW
EXECUTE PROCEDURE trg_restock_suma_stock();

-- --- Stock: detalle_pedido resta (insert / update / delete) ------------------

CREATE OR REPLACE FUNCTION trg_detalle_pedido_mueve_stock()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  delta INT;
BEGIN
  IF TG_OP = 'INSERT' THEN
    delta := -NEW.cantidad;
  ELSIF TG_OP = 'DELETE' THEN
    delta := OLD.cantidad;
  ELSE
    delta := OLD.cantidad - NEW.cantidad;
  END IF;

  IF TG_OP IN ('INSERT', 'UPDATE') THEN
    IF (SELECT b.stock + delta FROM bombon b WHERE b.id_bombon = NEW.id_bombon) < 0 THEN
      RAISE EXCEPTION 'Stock insuficiente para el bombón % (stock actual %, ajuste %)',
        NEW.id_bombon,
        (SELECT b2.stock FROM bombon b2 WHERE b2.id_bombon = NEW.id_bombon),
        delta;
    END IF;
  END IF;

  IF TG_OP = 'INSERT' THEN
    UPDATE bombon SET stock = stock + delta WHERE id_bombon = NEW.id_bombon;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE bombon SET stock = stock + delta WHERE id_bombon = OLD.id_bombon;
  ELSE
    IF OLD.id_bombon IS DISTINCT FROM NEW.id_bombon THEN
      RAISE EXCEPTION 'No se permite cambiar id_bombon en detalle_pedido; borra la fila e inserta otra';
    END IF;
    UPDATE bombon SET stock = stock + delta WHERE id_bombon = NEW.id_bombon;
  END IF;

  RETURN COALESCE(NEW, OLD);
END;
$$;

CREATE TRIGGER detalle_pedido_biud_stock
BEFORE INSERT OR UPDATE OR DELETE ON detalle_pedido
FOR EACH ROW
EXECUTE PROCEDURE trg_detalle_pedido_mueve_stock();

COMMENT ON TABLE cliente IS 'Clientes de la tienda / pedidos.';
COMMENT ON TABLE pedido IS 'Pedido asociado a un cliente; líneas en detalle_pedido.';
COMMENT ON TABLE detalle_pedido IS 'Líneas del pedido: bombón y cantidad. PK compuesta (id_pedido, id_bombon).';
COMMENT ON TABLE caja IS 'Caja física con QR único, ligada a un pedido.';
COMMENT ON TABLE bombon IS 'Catálogo de bombones; stock mantenido por triggers (detalle_pedido, restock).';
COMMENT ON TABLE restock IS 'Entrada de mercancía: incrementa stock del bombón referenciado.';
COMMENT ON TABLE palet IS 'Pallets de almacén; sin FK en el diagrama (añadir id_pedido si enlazas a envíos).';

COMMIT;
