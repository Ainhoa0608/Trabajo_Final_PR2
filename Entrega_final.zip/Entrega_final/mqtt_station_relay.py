"""
Puente MQTT (sin bucles): Chocolatillo -> Proyectos (RoboDK).

- Escucha: .../status en Chocolatillo (numero de combinacion, ej. "7")
- Publica:  .../command en Proyectos como JSON para RoboDK
- Ignora:   "ready 1" y otros textos (eso lo publica RoboDK en status)

Ejecutar: python mqtt_station_relay.py
"""

import json
import os
import random
import re
import ssl
import string
import threading
from typing import Any, Optional, Tuple
from urllib.parse import urlparse

import certifi
from dotenv import load_dotenv
from paho.mqtt import client as mqtt_client
from paho.mqtt.enums import CallbackAPIVersion

load_dotenv()

MQTT_URL = os.getenv("MQTT_URL", "").strip()
MQTT_USERNAME = os.getenv("MQTT_USERNAME", "").strip()
MQTT_PASSWORD = os.getenv("MQTT_PASSWORD", "").strip()

STATION_BASE = os.getenv("STATION_BASE", "giirob/pr2/station/demo").strip().rstrip("/")
STATION_STATUS_TOPIC = os.getenv("STATION_STATUS_TOPIC", f"{STATION_BASE}/status").strip()
STATION_COMMAND_TOPIC = os.getenv(
    "PROYECTOS_STATION_TOPIC", f"{STATION_BASE}/command"
).strip()
# MQTTX / RoboDK suelen usar "commands" (plural) — aqui debe verse el numero
STATION_COMMANDS_TOPIC = os.getenv(
    "STATION_COMMANDS_TOPIC", f"{STATION_BASE}/commands"
).strip()

PROYECTOS_MQTT_HOST = os.getenv("PROYECTOS_MQTT_HOST", "mqtt.dsic.upv.es").strip()
PROYECTOS_MQTT_PORT = int(os.getenv("PROYECTOS_MQTT_PORT", "1883"))
PROYECTOS_MQTT_USERNAME = os.getenv("PROYECTOS_MQTT_USERNAME", "giirob").strip()
PROYECTOS_MQTT_PASSWORD = os.getenv("PROYECTOS_MQTT_PASSWORD", "").strip()

COMMAND_AS_JSON = os.getenv("STATION_COMMAND_JSON", "true").lower() in ("1", "true", "yes")

_reeenviando = threading.local()


def _marcar_reeenvio() -> None:
    _reeenviando.activo = True


def _desmarcar_reeenvio() -> None:
    _reeenviando.activo = False


def _es_reeenvio() -> bool:
    return bool(getattr(_reeenviando, "activo", False))


def extraer_numero_combinacion(payload: bytes) -> Optional[int]:
    """Lee el numero de combinacion (1-99). Ignora 'ready 1' de RoboDK."""
    texto = payload.decode("utf-8", errors="replace").strip()
    if not texto:
        return None
    if texto.lower().startswith("ready"):
        print(f"  (ignorado en status: {texto!r} — es de RoboDK)")
        return None
    try:
        data = json.loads(texto)
        if isinstance(data, dict):
            estado = str(data.get("estado") or "").lower()
            if "rechazado" in estado or data.get("rechazado") is True:
                print(f"  (ignorado en status: pedido rechazado — {texto!r})")
                return None
            for clave in ("numeroCombi", "cmd", "numero"):
                if clave in data:
                    n = int(data[clave])
                    if 1 <= n <= 99:
                        return n
    except (json.JSONDecodeError, TypeError, ValueError):
        pass
    if re.fullmatch(r"\d+", texto):
        n = int(texto)
        if 1 <= n <= 99:
            return n
    print(f"  (ignorado: no es numero de combinacion: {texto!r})")
    return None


def payloads_para_proyectos(numero: int) -> Tuple[bytes, bytes]:
    """(texto plano para commands, JSON para command)"""
    plano = str(numero).encode("utf-8")
    if COMMAND_AS_JSON:
        json_b = json.dumps(
            {"numeroCombi": numero, "cmd": numero}, ensure_ascii=False
        ).encode("utf-8")
    else:
        json_b = plano
    return plano, json_b


def parse_mqtt_url(url: str) -> Tuple[str, int, str, bool, bool]:
    u = urlparse(url)
    host = u.hostname or ""
    if not host:
        raise ValueError("URL MQTT sin host")
    scheme = (u.scheme or "mqtt").lower()
    port = u.port
    if port is None:
        if scheme in ("wss", "https"):
            port = 443
        elif scheme in ("mqtts", "ssl"):
            port = 8883
        elif scheme in ("ws", "http"):
            port = 80
        else:
            port = 1883
    path = u.path or "/mqtt"
    if not path.startswith("/"):
        path = "/" + path
    use_ws = scheme in ("ws", "wss", "http", "https")
    use_tls = scheme in ("mqtts", "wss", "https", "ssl")
    return host, port, path, use_ws, use_tls


def crear_cliente(
    url: str,
    username: str,
    password: str,
    client_id_prefix: str,
    *,
    host: str = "",
    port: int = 0,
) -> mqtt_client.Client:
    if url:
        host, port, path, use_ws, use_tls = parse_mqtt_url(url)
    else:
        path = ""
        use_ws = False
        use_tls = False

    cid = f"{client_id_prefix}_" + "".join(
        random.choices(string.ascii_lowercase + string.digits, k=8)
    )
    cli = mqtt_client.Client(
        callback_api_version=CallbackAPIVersion.VERSION2,
        client_id=cid,
        transport="websockets" if use_ws else "tcp",
    )
    if use_ws:
        cli.ws_set_options(path=path)
    if use_tls:
        cli.tls_set(ca_certs=certifi.where(), cert_reqs=ssl.CERT_REQUIRED)
    cli.username_pw_set(username, password)
    return cli


def comprobar_config() -> None:
    if not MQTT_URL or not MQTT_USERNAME or not MQTT_PASSWORD:
        raise SystemExit("Faltan MQTT_URL, MQTT_USERNAME o MQTT_PASSWORD en .env")
    if not PROYECTOS_MQTT_PASSWORD:
        raise SystemExit("Falta PROYECTOS_MQTT_PASSWORD en .env")


def publicar(
    client: mqtt_client.Client,
    topic: str,
    payload: bytes,
) -> None:
    _marcar_reeenvio()
    try:
        # retain=False: RoboDK debe recibir comando nuevo, no uno viejo del broker
        info = client.publish(topic, payload, qos=0, retain=False)
        if info.rc != mqtt_client.MQTT_ERR_SUCCESS:
            print(f"ERROR publicando en {topic}: rc={info.rc}")
    finally:
        _desmarcar_reeenvio()


def main() -> None:
    comprobar_config()

    proyectos = crear_cliente(
        "",
        PROYECTOS_MQTT_USERNAME,
        PROYECTOS_MQTT_PASSWORD,
        "relay_dst",
        host=PROYECTOS_MQTT_HOST,
        port=PROYECTOS_MQTT_PORT,
    )

    choco = crear_cliente(MQTT_URL, MQTT_USERNAME, MQTT_PASSWORD, "relay_src")

    def on_connect_proyectos(
        client: mqtt_client.Client,
        userdata: Any,
        flags: Any,
        reason_code: Any,
        properties: Any = None,
    ) -> None:
        if getattr(reason_code, "is_failure", False):
            print(f"Proyectos: error {reason_code}")
            return
        print(f"Proyectos OK -> commands: {STATION_COMMANDS_TOPIC}")
        if STATION_COMMAND_TOPIC != STATION_COMMANDS_TOPIC:
            print(f"            -> command:  {STATION_COMMAND_TOPIC}")

    def on_connect_choco(
        client: mqtt_client.Client,
        userdata: Any,
        flags: Any,
        reason_code: Any,
        properties: Any = None,
    ) -> None:
        if getattr(reason_code, "is_failure", False):
            print(f"Chocolatillo: error {reason_code}")
            return
        client.subscribe(STATION_STATUS_TOPIC, qos=0)
        print(f"Chocolatillo OK -> status: {STATION_STATUS_TOPIC}")

    def on_message_choco(
        client: mqtt_client.Client,
        userdata: Any,
        msg: mqtt_client.MQTTMessage,
    ) -> None:
        if _es_reeenvio() or msg.topic != STATION_STATUS_TOPIC:
            return
        texto_in = msg.payload.decode("utf-8", errors="replace").strip()
        print(f"Chocolatillo [{msg.topic}] {texto_in!r}")
        numero = extraer_numero_combinacion(msg.payload)
        if numero is None:
            return
        plano, json_b = payloads_para_proyectos(numero)
        # Numero visible en MQTTX (topic commands, texto "7", "25", etc.)
        publicar(proyectos, STATION_COMMANDS_TOPIC, plano)
        print(f"  -> Proyectos [{STATION_COMMANDS_TOPIC}] {numero!r}")
        if STATION_COMMAND_TOPIC and STATION_COMMAND_TOPIC != STATION_COMMANDS_TOPIC:
            publicar(proyectos, STATION_COMMAND_TOPIC, json_b)
            print(f"  -> Proyectos [{STATION_COMMAND_TOPIC}] {json_b.decode()!r}")

    proyectos.on_connect = on_connect_proyectos
    choco.on_connect = on_connect_choco
    choco.on_message = on_message_choco

    print("Puente: Chocolatillo status -> Proyectos commands (numero combinacion)")
    print(f"  En MQTTX suscribete a: {STATION_COMMANDS_TOPIC}")
    print(f"  (status solo muestra 'ready 1' de RoboDK; el numero va en commands)")
    print()

    proyectos.connect(PROYECTOS_MQTT_HOST, PROYECTOS_MQTT_PORT, keepalive=60)
    proyectos.loop_start()

    host, port, _, _, _ = parse_mqtt_url(MQTT_URL)
    choco.connect(host, port, keepalive=60)
    print("Activo. Haz un pedido en la web con relay + mqtt_bridge corriendo.\n")
    try:
        choco.loop_forever()
    except KeyboardInterrupt:
        print("\nCerrando...")
    finally:
        choco.loop_stop()
        choco.disconnect()
        proyectos.loop_stop()
        proyectos.disconnect()


if __name__ == "__main__":
    main()
