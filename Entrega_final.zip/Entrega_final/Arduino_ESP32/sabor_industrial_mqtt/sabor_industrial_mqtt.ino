#include <WiFi.h>

#include <PubSubClient.h>

#include "secrets.h"



#if MQTT_USE_TLS

#include <WiFiClientSecure.h>

WiFiClientSecure net;

#else

WiFiClient net;

#endif



PubSubClient mqtt(net);



// 2 botones: GPIO 4 = PER, GPIO 5 = STOP (GPIO 6 no se usa)

const uint8_t BTN_PER = 4;

const uint8_t BTN_STOP = 5;

// Ultrasonido HC-SR04 (ajusta pines si usas otros)
const uint8_t US_TRIG = 6;
const uint8_t US_ECHO = 7;
const float DIST_UMBRAL_CM = 7.0f;      // < 7 cm => SLOW
const float DIST_LIBERA_CM = 9.0f;      // histéresis para volver a NORMAL
const unsigned long US_INTERVAL_MS = 150;



bool antes_per = false;

bool antes_stop = false;
bool modo_lento = false;
unsigned long t_us_prev = 0;



#ifndef MQTT_TOPIC_COMMANDS

#define MQTT_TOPIC_COMMANDS "giirob/pr2/station/demo/commands"

#endif



void conectarWifiYMqtt() {

  if (WiFi.status() != WL_CONNECTED) {

    Serial.printf("Conectando WiFi %s...\n", WIFI_SSID);

    WiFi.mode(WIFI_STA);

    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

    while (WiFi.status() != WL_CONNECTED) {

      delay(300);

      Serial.print(".");

    }

    Serial.println();

    Serial.print("WiFi OK IP: ");

    Serial.println(WiFi.localIP());

  }



  if (!mqtt.connected()) {

    mqtt.setServer(MQTT_HOST, MQTT_PORT);

#if MQTT_USE_TLS

    net.setInsecure();

#endif

    String id = "esp32-botones-" + String((uint32_t)ESP.getEfuseMac(), HEX);

    Serial.printf("Conectando MQTT %s:%d...\n", MQTT_HOST, MQTT_PORT);

    if (mqtt.connect(id.c_str(), MQTT_USER, MQTT_PASS)) {

      Serial.println("MQTT OK");

    } else {

      Serial.print("MQTT fallo, rc=");

      Serial.println(mqtt.state());

    }

  }

}



void publicarComando(const char* comando) {

  if (!mqtt.connected()) {

    Serial.println("No publico: MQTT desconectado");

    return;

  }

  bool ok = mqtt.publish(MQTT_TOPIC_COMMANDS, comando);

  Serial.printf("Publish [%s] -> %s (%s)\n",

                MQTT_TOPIC_COMMANDS, comando, ok ? "OK" : "FALLO");

}


float leerDistanciaCm() {
  digitalWrite(US_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(US_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(US_TRIG, LOW);

  // timeout 30 ms ~ 5m
  unsigned long dur = pulseIn(US_ECHO, HIGH, 30000);
  if (dur == 0) return -1.0f;
  return (dur * 0.0343f) / 2.0f;
}



void setup() {

  Serial.begin(115200);

  delay(1000);

  Serial.println("\n=== ESP32 botones PER / STOP ===");



  pinMode(BTN_PER, INPUT_PULLUP);

  pinMode(BTN_STOP, INPUT_PULLUP);
  pinMode(US_TRIG, OUTPUT);
  pinMode(US_ECHO, INPUT);



  conectarWifiYMqtt();

  Serial.println("Listo: GPIO 4=PER, GPIO 5=STOP");

  Serial.printf("Topic commands: %s\n", MQTT_TOPIC_COMMANDS);
  Serial.printf("Ultrasonido TRIG=%u ECHO=%u | umbral=%.1f cm\n",
                US_TRIG, US_ECHO, DIST_UMBRAL_CM);

}



void loop() {

  conectarWifiYMqtt();

  mqtt.loop();



  bool p_per = (digitalRead(BTN_PER) == LOW);

  bool p_stop = (digitalRead(BTN_STOP) == LOW);



  if (p_per && !antes_per) {

    Serial.println("Boton PER (GPIO 4)");

    publicarComando("PER");

  }

  if (p_stop && !antes_stop) {

    Serial.println("Boton STOP (GPIO 5)");

    publicarComando("STOP");

  }



  antes_per = p_per;

  antes_stop = p_stop;

  // Ultrasonido -> comandos SLOW / NORMAL
  unsigned long now_ms = millis();
  if (now_ms - t_us_prev >= US_INTERVAL_MS) {
    t_us_prev = now_ms;
    float d = leerDistanciaCm();
    if (d > 0) {
      if (!modo_lento && d < DIST_UMBRAL_CM) {
        modo_lento = true;
        Serial.printf("Ultrasonido: %.2f cm -> SLOW\n", d);
        publicarComando("SLOW");
      } else if (modo_lento && d > DIST_LIBERA_CM) {
        modo_lento = false;
        Serial.printf("Ultrasonido: %.2f cm -> NORMAL\n", d);
        publicarComando("NORMAL");
      }
    }
  }



  delay(40);

}

