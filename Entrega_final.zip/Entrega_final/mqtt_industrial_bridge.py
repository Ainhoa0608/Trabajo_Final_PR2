"""
Puente MQTT: EMQX (ESP32) -> UPV mqtt.dsic.upv.es (RoboDK)

El ESP32 publica PER/STOP en EMQX en:
  giirob/pr2/station/demo/commands

Este script reenvia esos mensajes al MISMO topic en el broker UPV.

Uso:
  python mqtt_industrial_bridge.py
"""

import os
import random
import ssl
import string
from urllib.parse import urlparse

import certifi
from dotenv import load_dotenv
from paho.mqtt import client as mqtt_client
from paho.mqtt.enums import CallbackAPIVersion

load_dotenv()

MQTT_URL = os.getenv("MQTT_URL", "").strip()
MQTT_USERNAME = os.getenv("MQTT_USERNAME", "").strip()
MQTT_PASSWORD = os.getenv("MQTT_PASSWORD", "").strip()

# Topics en EMQX donde escuchar (separados por coma)
# Por defecto: el mismo topic al que publica el ESP32
DEFAULT_EMQX_TOPICS = "giirob/pr2/station/demo/commands"
EMQX_SOURCE_TOPICS = os.getenv("EMQX_SOURCE_TOPICS", DEFAULT_EMQX_TOPICS).strip()

PROYECTOS_MQTT_HOST = os.getenv("PROYECTOS_MQTT_HOST", "mqtt.dsic.upv.es").strip()
PROYECTOS_MQTT_PORT = int(os.getenv("PROYECTOS_MQTT_PORT", "1883"))
PROYECTOS_MQTT_USERNAME = os.getenv("PROYECTOS_MQTT_USERNAME", "giirob").strip()
PROYECTOS_MQTT_PASSWORD = os.getenv("PROYECTOS_MQTT_PASSWORD", "").strip()
DEST_COMMANDS_TOPIC = os.getenv(
    "STATION_COMMANDS_TOPIC", "giirob/pr2/station/demo/commands"
).strip()


def parse_mqtt_url(url: str):
    u = urlparse(url)
    host = u.hostname or ""
    if not host:
        raise ValueError("MQTT_URL sin host")
    scheme = (u.scheme or "mqtt").lower()
    port = u.port
    if port is None:
        if scheme in ("wss", "https"):
            port = 443
        elif scheme in ("mqtts", "ssl"):
            port = 8883
        elif scheme in ("ws", "http"):
            port = 80
        else:
            port = 1883
    path = u.path or "/mqtt"
    if not path.startswith("/"):
        path = "/" + path
    use_ws = scheme in ("ws", "wss", "http", "https")
    use_tls = scheme in ("mqtts", "wss", "https", "ssl")
    return host, port, path, use_ws, use_tls


def new_client(prefix: str, use_ws=False):
    cid = f"{prefix}_" + "".join(
        random.choices(string.ascii_lowercase + string.digits, k=8)
    )
    return mqtt_client.Client(
        callback_api_version=CallbackAPIVersion.VERSION2,
        client_id=cid,
        transport="websockets" if use_ws else "tcp",
    )


def parse_source_topics(raw: str):
    topics = [t.strip() for t in raw.split(",") if t.strip()]
    return topics or [DEFAULT_EMQX_TOPICS]


def extract_cmd(topic: str, payload_b: bytes):
    text = payload_b.decode("utf-8", errors="replace").strip().upper()
    if text in ("PER", "STOP", "SLOW", "NORMAL"):
        return text
    last = topic.strip().split("/")[-1].upper()
    if last in ("PER", "STOP", "SLOW", "NORMAL"):
        return last
    return None


def main():
    if not MQTT_URL or not MQTT_USERNAME or not MQTT_PASSWORD:
        raise SystemExit("Faltan MQTT_URL/MQTT_USERNAME/MQTT_PASSWORD en .env")
    if not PROYECTOS_MQTT_PASSWORD:
        raise SystemExit("Falta PROYECTOS_MQTT_PASSWORD en .env")

    source_topics = parse_source_topics(EMQX_SOURCE_TOPICS)

    dst = new_client("btn_dst", use_ws=False)
    dst.username_pw_set(PROYECTOS_MQTT_USERNAME, PROYECTOS_MQTT_PASSWORD)
    dst.connect(PROYECTOS_MQTT_HOST, PROYECTOS_MQTT_PORT, keepalive=60)
    dst.loop_start()

    host, port, path, use_ws, use_tls = parse_mqtt_url(MQTT_URL)
    src = new_client("btn_src", use_ws=use_ws)
    if use_ws:
        src.ws_set_options(path=path)
    if use_tls:
        src.tls_set(ca_certs=certifi.where(), cert_reqs=ssl.CERT_REQUIRED)
    src.username_pw_set(MQTT_USERNAME, MQTT_PASSWORD)

    def on_connect(client, userdata, flags, reason_code, properties=None):
        if getattr(reason_code, "is_failure", False):
            print(f"EMQX connect error: {reason_code}")
            return
        for topic in source_topics:
            client.subscribe(topic, qos=0)
            print(f"EMQX OK -> subscribed: {topic}")
        print(f"UPV  OK -> reenvio a: {DEST_COMMANDS_TOPIC} (PER / STOP / SLOW / NORMAL)")

    def on_message(client, userdata, msg):
        cmd = extract_cmd(msg.topic, msg.payload)
        raw = msg.payload.decode("utf-8", errors="replace").strip()
        print(f"EMQX [{msg.topic}] {raw!r}")
        if cmd is None:
            print("  Ignorado (esperado PER/STOP/SLOW/NORMAL)")
            return
        payload_out = cmd.encode("utf-8")
        info = dst.publish(DEST_COMMANDS_TOPIC, payload_out, qos=0, retain=False)
        if info.rc == mqtt_client.MQTT_ERR_SUCCESS:
            print(f"  -> UPV [{DEST_COMMANDS_TOPIC}] {payload_out.decode()!r}")
        else:
            print(f"  ERROR publicando en UPV rc={info.rc}")

    src.on_connect = on_connect
    src.on_message = on_message

    print("Puente ESP32 -> UPV activo. Ctrl+C para salir.")
    print("Escuchando en EMQX:", ", ".join(source_topics))
    src.connect(host, port, keepalive=60)
    try:
        src.loop_forever()
    except KeyboardInterrupt:
        pass
    finally:
        src.loop_stop()
        src.disconnect()
        dst.loop_stop()
        dst.disconnect()


if __name__ == "__main__":
    main()
